const API_BASE = "/api";
const donationBox = document.getElementById("donation-box");
const donationBar = document.getElementById("donation-progress-bar");
const donationText = document.getElementById("donation-text");

const productsContainer = document.getElementById("products-container");
const cartButton = document.getElementById("cart-button");
const cartModal = document.getElementById("cart-modal");
const cartItemsList = document.getElementById("cart-items");
const cartTotalDisplay = document.getElementById("cart-total");
const closeCartBtn = document.getElementById("close-cart-btn");
const checkoutBtn = document.getElementById("checkout-btn");
const checkoutModal = document.getElementById("checkout-modal");
const checkoutForm = document.getElementById("checkout-form");
const cancelCheckoutBtn = document.getElementById("cancel-checkout-btn");

const adminLoginBtn = document.getElementById("admin-login-btn");
const adminLoginModal = document.getElementById("admin-login-modal");
const adminLoginForm = document.getElementById("admin-login-form");
const adminLoginCancelBtn = document.getElementById("admin-login-cancel-btn");

let sessionId = localStorage.getItem("idex_session") || generateSessionId();
localStorage.setItem("idex_session", sessionId);

let cart = {};

function generateSessionId() {
  return "sess_" + Math.random().toString(36).substr(2, 12);
}

// Fetch products from backend and render
async function fetchProducts() {
  try {
    const res = await fetch(`${API_BASE}/products`);
    if (!res.ok) throw new Error("Failed to fetch products");
    const data = await res.json();
    renderProducts(data);
  } catch (e) {
    productsContainer.innerHTML = "<p>Error loading products.</p>";
  }
}

// Render product cards
function renderProducts(products) {
  productsContainer.innerHTML = "";
  for (const [id, p] of Object.entries(products)) {
    const card = document.createElement("article");
    card.className = "product-card";
    card.tabIndex = 0;

    const img = document.createElement("img");
    img.src = p.image || "https://via.placeholder.com/300x180?text=No+Image";
    img.alt = p.name;
    card.appendChild(img);

    const title = document.createElement("h3");
    title.textContent = p.name;
    card.appendChild(title);

    const desc = document.createElement("p");
    desc.textContent = p.description || "No description";
    card.appendChild(desc);

    const price = document.createElement("div");
    price.className = "price";
    price.textContent = `$${(p.price || 0).toFixed(2)}`;
    card.appendChild(price);

    const btn = document.createElement("button");
    btn.textContent = "Add to Cart";
    btn.setAttribute("aria-label", `Add ${p.name} to cart`);
    btn.addEventListener("click", () => addToCart(id));
    card.appendChild(btn);

    productsContainer.appendChild(card);
  }
}

// Add product to cart (backend)
async function addToCart(productId) {
  try {
    const res = await fetch(`${API_BASE}/cart/add`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({product_id: productId, quantity: 1, session_id: sessionId}),
    });
    if (!res.ok) throw new Error("Add to cart failed");
    const data = await res.json();
    cart = data.cart;
    updateCartCount();
  } catch (e) {
    alert("Failed to add item to cart.");
  }
}

function updateCartCount() {
  const count = Object.values(cart).reduce((a,b) => a+b, 0);
  document.getElementById("cart-count").textContent = count;
}

// Show cart modal
cartButton.addEventListener("click", () => {
  renderCart();
  openModal(cartModal);
});

// Close cart modal
closeCartBtn.addEventListener("click", () => closeModal(cartModal));

// Render cart items list
function renderCart() {
  cartItemsList.innerHTML = "";
  let total = 0;
  for (const [pid, qty] of Object.entries(cart)) {
    const li = document.createElement("li");
    li.textContent = `${qty} × ${pid}`;
    cartItemsList.appendChild(li);
    // Sum total price (you could fetch product price for real)
    // Simplify: skip price calc here for brevity
  }
  cartTotalDisplay.textContent = `Total: $${total.toFixed(2)}`;
}

// Checkout flow
checkoutBtn.addEventListener("click", () => {
  closeModal(cartModal);
  openModal(checkoutModal);
});

cancelCheckoutBtn.addEventListener("click", () => {
  closeModal(checkoutModal);
});

checkoutForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = {
    name: checkoutForm.name.value,
    email: checkoutForm.email.value,
    address: checkoutForm.address.value,
    session_id: sessionId,
  };
  try {
    const res = await fetch(`${API_BASE}/checkout`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(formData),
    });
    if (!res.ok) throw new Error("Checkout failed");
    const data = await res.json();
    alert("Order placed! Thank you!");
    cart = {};
    updateCartCount();
    closeModal(checkoutModal);
  } catch (e) {
    alert("Checkout error. Try again.");
  }
});

// Donation box logic

async function fetchDonationProgress() {
  try {
    const res = await fetch(`${API_BASE}/donation/progress`);
    if (!res.ok) throw new Error("Failed to fetch donation progress");
    const data = await res.json();
    updateDonationUI(data);
  } catch {
    donationText.textContent = "Donation info unavailable";
  }
}

function updateDonationUI({total, target, percent}) {
  donationBar.style.width = `${percent}%`;
  donationText.textContent = `$${total.toFixed(2)} / $${target} donated`;
}

donationBox.addEventListener("click", () => {
  window.location.href = "/donation";
});

donationBox.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    donationBox.click();
  }
});

// Modal helpers

function openModal(modal) {
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
}

function closeModal(modal) {
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

// Admin login modal

adminLoginBtn.addEventListener("click", () => {
  openModal(adminLoginModal);
});

adminLoginCancelBtn.addEventListener("click", () => {
  closeModal(adminLoginModal);
});

adminLoginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const password = adminLoginForm["admin-password"].value;
  // Simple login to get token for AI commands
  // In real app, securely handle tokens & sessions
  const token = btoa(password); // Fake token (base64 password)

  try {
    // Test auth by sending a dummy AI command
    const res = await fetch(`${API_BASE}/admin/ai_command`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${password}`, // Send raw for demo
      },
      body: JSON.stringify({prompt: "test"}),
    });
    if (!res.ok) throw new Error("Invalid password");
    alert("Admin login successful!");
    localStorage.setItem("admin_token", password);
    closeModal(adminLoginModal);
    // Redirect to admin console page
    window.location.href = "/admin";
  } catch {
    alert("Admin login failed. Incorrect password.");
  }
});

// Initialization
fetchProducts();
fetchDonationProgress();
updateCartCount();
