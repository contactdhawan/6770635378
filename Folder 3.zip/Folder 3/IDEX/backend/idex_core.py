import json
import threading
import time
from utils.logger import log_action
from utils.validator import validate_order

_PRODUCTS_FILE = "backend/products.json"
_ORDERS_FILE = "backend/orders.json"
_COINS_FILE = "backend/idex_coins.json"
_LOCK = threading.Lock()


def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_products():
    try:
        return _load_json(_PRODUCTS_FILE)
    except Exception as e:
        log_action("error", {"msg": "Failed to load products", "error": str(e)})
        return []


def save_products(products):
    try:
        _save_json(_PRODUCTS_FILE, products)
        log_action("products_saved", {"count": len(products)})
        return True
    except Exception as e:
        log_action("error", {"msg": "Failed to save products", "error": str(e)})
        return False


def process_order(order_data):
    """Process an order, validate, update orders and coins."""
    with _LOCK:
        try:
            # Validate order schema & stock
            valid, msg = validate_order(order_data)
            if not valid:
                return {"success": False, "error": msg}

            # Load current orders and coins
            orders = _load_json(_ORDERS_FILE)
            coins = _load_json(_COINS_FILE)

            # Calculate total and add order
            total = 0
            for item in order_data["items"]:
                total += item["price"] * item["quantity"]

            order_record = {
                "id": int(time.time() * 1000),
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "items": order_data["items"],
                "total": total,
                "user": order_data.get("user", "guest"),
                "status": "pending",
            }
            orders.append(order_record)

            # Update orders file
            _save_json(_ORDERS_FILE, orders)

            # Award IDEX coins based on order total (e.g., 1 coin per $10)
            awarded_coins = int(total // 10)
            coins[order_record["user"]] = coins.get(order_record["user"], 0) + awarded_coins
            _save_json(_COINS_FILE, coins)

            log_action("order_processed", {"order_id": order_record["id"], "coins_awarded": awarded_coins})

            return {"success": True, "order_id": order_record["id"], "coins_awarded": awarded_coins}

        except Exception as e:
            log_action("error", {"msg": "Order processing failed", "error": str(e)})
            return {"success": False, "error": "Internal server error"}


def add_product(product):
    """Add a new product."""
    with _LOCK:
        try:
            products = _load_json(_PRODUCTS_FILE)
            product["id"] = max((p.get("id", 0) for p in products), default=0) + 1
            products.append(product)
            _save_json(_PRODUCTS_FILE, products)
            log_action("product_added", {"product_id": product["id"]})
            return True
        except Exception as e:
            log_action("error", {"msg": "Add product failed", "error": str(e)})
            return False


def update_product(product_id, updates):
    """Update existing product by id."""
    with _LOCK:
        try:
            products = _load_json(_PRODUCTS_FILE)
            for p in products:
                if p.get("id") == product_id:
                    p.update(updates)
                    _save_json(_PRODUCTS_FILE, products)
                    log_action("product_updated", {"product_id": product_id, "updates": updates})
                    return True
            return False
        except Exception as e:
            log_action("error", {"msg": "Update product failed", "error": str(e)})
            return False


def remove_product(product_id):
    """Remove product by id."""
    with _LOCK:
        try:
            products = _load_json(_PRODUCTS_FILE)
            new_products = [p for p in products if p.get("id") != product_id]
            if len(new_products) == len(products):
                return False  # No product found to remove
            _save_json(_PRODUCTS_FILE, new_products)
            log_action("product_removed", {"product_id": product_id})
            return True
        except Exception as e:
            log_action("error", {"msg": "Remove product failed", "error": str(e)})
            return False
