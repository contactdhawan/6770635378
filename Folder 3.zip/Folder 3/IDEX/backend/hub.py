import json
import threading
import os
from datetime import datetime

LOCK = threading.Lock()

DATA_DIR = os.path.join(os.path.dirname(__file__))
PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
DONATIONS_FILE = os.path.join(DATA_DIR, "donations.json")
IDEX_COINS_FILE = os.path.join(DATA_DIR, "idex_coins.json")

# In-memory carts per session (simulate for now)
CARTS = {}

def _read_json(filepath):
    if not os.path.exists(filepath):
        return {}
    with LOCK:
        with open(filepath, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}

def _write_json(filepath, data):
    with LOCK:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

# Products

def get_products():
    products = _read_json(PRODUCTS_FILE)
    return products

def add_product(product_data):
    products = _read_json(PRODUCTS_FILE)
    product_id = product_data.get("id") or f"prod_{int(datetime.utcnow().timestamp()*1000)}"
    if product_id in products:
        raise ValueError("Product ID already exists")
    products[product_id] = product_data
    _write_json(PRODUCTS_FILE, products)
    return product_id

def update_product(product_id, updated_data):
    products = _read_json(PRODUCTS_FILE)
    if product_id not in products:
        raise ValueError("Product not found")
    products[product_id].update(updated_data)
    _write_json(PRODUCTS_FILE, products)

def delete_product(product_id):
    products = _read_json(PRODUCTS_FILE)
    if product_id not in products:
        raise ValueError("Product not found")
    del products[product_id]
    _write_json(PRODUCTS_FILE, products)

# Cart Operations

def add_to_cart(session_id, product_id, quantity=1):
    products = _read_json(PRODUCTS_FILE)
    if product_id not in products:
        raise ValueError("Product not found")
    if quantity < 1:
        raise ValueError("Quantity must be >= 1")
    cart = CARTS.setdefault(session_id, {})
    cart[product_id] = cart.get(product_id, 0) + quantity
    return {"message": "Added to cart", "cart": cart}

def remove_from_cart(session_id, product_id, quantity=1):
    cart = CARTS.get(session_id, {})
    if product_id not in cart:
        raise ValueError("Product not in cart")
    if quantity < 1:
        raise ValueError("Quantity must be >= 1")
    cart[product_id] -= quantity
    if cart[product_id] <= 0:
        del cart[product_id]
    return {"message": "Removed from cart", "cart": cart}

def get_cart(session_id):
    return CARTS.get(session_id, {})

# Order Processing

def process_checkout(session_id, checkout_data):
    cart = CARTS.get(session_id, {})
    if not cart:
        raise ValueError("Cart is empty")
    orders = _read_json(ORDERS_FILE)
    order_id = f"order_{int(datetime.utcnow().timestamp()*1000)}"
    order = {
        "id": order_id,
        "items": cart,
        "checkout_data": checkout_data,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "pending"
    }
    orders[order_id] = order
    _write_json(ORDERS_FILE, orders)
    # Clear cart after order
    CARTS[session_id] = {}
    return order

# Donations

def get_donation_progress():
    donations = _read_json(DONATIONS_FILE)
    total = sum(d.get("amount", 0) for d in donations.values()) if isinstance(donations, dict) else 0
    target = 100  # fixed $100 target
    percent = min(int((total / target) * 100), 100)
    return {"total": total, "target": target, "percent": percent}

def add_donation(donor_id, amount):
    if amount <= 0:
        raise ValueError("Donation amount must be positive")
    donations = _read_json(DONATIONS_FILE)
    donations[donor_id] = donations.get(donor_id, {"amount": 0})
    donations[donor_id]["amount"] += amount
    _write_json(DONATIONS_FILE, donations)
    return donations[donor_id]

# IDEX Coins (simple wallet system)

def get_idex_coins(user_id):
    coins = _read_json(IDEX_COINS_FILE)
    return coins.get(user_id, 0)

def add_idex_coins(user_id, amount):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    coins = _read_json(IDEX_COINS_FILE)
    coins[user_id] = coins.get(user_id, 0) + amount
    _write_json(IDEX_COINS_FILE, coins)
    return coins[user_id]

def spend_idex_coins(user_id, amount):
    if amount <= 0:
        raise ValueError("Amount must be positive")
    coins = _read_json(IDEX_COINS_FILE)
    balance = coins.get(user_id, 0)
    if balance < amount:
        raise ValueError("Insufficient IDEX coins")
    coins[user_id] = balance - amount
    _write_json(IDEX_COINS_FILE, coins)
    return coins[user_id]
