import json
import os
from datetime import datetime

DATA_DIR = os.path.dirname(__file__)
CHANGELOG_FILE = os.path.join(DATA_DIR, "changelog.json")
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")

def _read_json(filepath):
    if not os.path.exists(filepath):
        return {}
    with open(filepath, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}

def _write_json(filepath, data):
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def log_change(command, success, details=None):
    changelog = _read_json(CHANGELOG_FILE)
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "command": command,
        "success": success,
        "details": details
    }
    changelog.setdefault("entries", []).append(entry)
    _write_json(CHANGELOG_FILE, changelog)

def process_command(prompt):
    """
    Simulated natural language command processing.

    In real use, connect to OpenAI API or your AI engine to parse
    and execute commands on the codebase or backend config.

    Here, we fake command handling for demo.
    """
    prompt = prompt.lower().strip()
    if "add product" in prompt:
        # Parse product details from prompt (stub)
        response = "Simulated: product added successfully."
        log_change(prompt, True, "Added new product.")
        return response
    elif "remove user" in prompt:
        response = "Simulated: user removed successfully."
        log_change(prompt, True, "Removed user.")
        return response
    elif "update price" in prompt:
        response = "Simulated: price updated successfully."
        log_change(prompt, True, "Updated product price.")
        return response
    elif "rollback" in prompt:
        # Would trigger rollback logic here
        response = "Simulated: rollback executed."
        log_change(prompt, True, "Rollback performed.")
        return response
    else:
        log_change(prompt, False, "Unknown command")
        return "Sorry, I did not understand that command."

def get_memory():
    return _read_json(MEMORY_FILE)

def save_memory(memory_data):
    _write_json(MEMORY_FILE, memory_data)
