from flask import Flask, render_template, send_from_directory, jsonify, request
from flask_cors import CORS
import os
import json
from backend import idex_core  # Assuming idex_core.py handles logic
from utils.logger import log_event

app = Flask(
    __name__,
    static_folder="public",
    template_folder="public"
)
CORS(app)

# === UI ROUTES ===

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/admin")
def admin():
    return render_template("admin.html")

@app.route("/donate")
def donation_page():
    return render_template("donation.html")

# === STATIC FILE HANDLING (if needed) ===

@app.route("/public/<path:path>")
def public_assets(path):
    return send_from_directory("public", path)

# === API ROUTES ===

@app.route("/api/products")
def get_products():
    with open("backend/products.json") as f:
        return jsonify(json.load(f))

@app.route("/api/orders", methods=["POST"])
def place_order():
    order = request.json
    success = idex_core.process_order(order)
    log_event("OrderPlaced", order)
    return jsonify({"success": success})

@app.route("/api/donations")
def get_donations():
    with open("backend/donations.json") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/api/donate", methods=["POST"])
def donate():
    amount = request.json.get("amount", 0)
    if amount <= 0:
        return jsonify({"success": False, "message": "Invalid amount"}), 400
    with open("backend/donations.json") as f:
        data = json.load(f)
    data["total"] += amount
    with open("backend/donations.json", "w") as f:
        json.dump(data, f, indent=2)
    log_event("DonationMade", {"amount": amount})
    return jsonify({"success": True, "new_total": data["total"]})

# === HEALTH CHECK ===

@app.route("/ping")
def ping():
    return jsonify({"status": "ok"})

# === MAIN RUN ===

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
