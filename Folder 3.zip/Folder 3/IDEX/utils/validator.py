# utils/validator.py

import re

def validate_email(email: str) -> bool:
    """Validate email address format"""
    return re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email) is not None

def validate_name(name: str) -> bool:
    """Ensure name is non-empty and alphabetic"""
    return bool(name.strip()) and name.replace(" ", "").isalpha()

def validate_address(address: str) -> bool:
    """Check that address is non-empty and long enough"""
    return bool(address.strip()) and len(address.strip()) > 5

def validate_order(order: dict) -> bool:
    """
    Validate a complete order dictionary.
    Expected keys: name, email, address, items (list of dicts), total (float)
    """
    required_keys = {"name", "email", "address", "items", "total"}
    if not all(key in order for key in required_keys):
        return False

    if not validate_name(order["name"]):
        return False

    if not validate_email(order["email"]):
        return False

    if not validate_address(order["address"]):
        return False

    if not isinstance(order["items"], list) or len(order["items"]) == 0:
        return False

    if not isinstance(order["total"], (float, int)) or order["total"] < 0:
        return False

    return True

def validate_product(product: dict) -> bool:
    """Validate a product dictionary"""
    required_keys = {"id", "name", "price"}
    if not all(key in product for key in required_keys):
        return False
    if not isinstance(product["price"], (float, int)) or product["price"] < 0:
        return False
    return True
