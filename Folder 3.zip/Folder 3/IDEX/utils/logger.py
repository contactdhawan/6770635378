# utils/logger.py

import logging
import os
from datetime import datetime

LOG_DIR = os.path.join(os.path.dirname(__file__), "..", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, f"idex_{datetime.now().strftime('%Y-%m-%d')}.log")

# Configure logger
logger = logging.getLogger("IDEX")
logger.setLevel(logging.DEBUG)

# File handler
file_handler = logging.FileHandler(LOG_FILE)
file_handler.setLevel(logging.DEBUG)

# Console handler
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Formatter
formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers to logger if not already added
if not logger.hasHandlers():
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

def get_logger(name=None):
    """Get a logger for a specific module"""
    return logger if name is None else logging.getLogger(name)

def log_action(action: str, user: str = "system", level: str = "info"):
    """Log a specific action in a consistent format"""
    message = f"[{user}] {action}"
    if level == "debug":
        logger.debug(message)
    elif level == "warning":
        logger.warning(message)
    elif level == "error":
        logger.error(message)
    else:
        logger.info(message)

import datetime
import os

LOG_FILE = "logs.txt"

def _write_log(entry: str):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True) if os.path.dirname(LOG_FILE) else None
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry + "\n")

def log_action(action: str, user: str = "system"):
    timestamp = datetime.datetime.now().isoformat()
    log_entry = f"[{timestamp}] ACTION by {user}: {action}"
    _write_log(log_entry)

def log_event(event: str, level: str = "INFO"):
    timestamp = datetime.datetime.now().isoformat()
    log_entry = f"[{timestamp}] {level}: {event}"
    _write_log(log_entry)

