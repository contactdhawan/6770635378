import tkinter as tk
from tkinter import ttk, font, messagebox
import datetime
import calendar
import json
import os
import sys

# === Setup Base Directory for saving log (works in .py and .exe) ===
def get_base_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)  # Running from bundled exe
    else:
        return os.path.dirname(os.path.abspath(__file__))

BASE_DIR = get_base_dir()
LOG_FILE = os.path.join(BASE_DIR, "japa_log.json")

# === Crash Popup ===
def show_exception(exc_type, exc_value, exc_traceback):
    import traceback
    error_msg = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    messagebox.showerror("Unexpected Error", error_msg)

sys.excepthook = show_exception

# === Load Log ===
try:
    with open(LOG_FILE, "r") as f:
        log_data = json.load(f)
except (FileNotFoundError, json.JSONDecodeError):
    log_data = {}

session_start = datetime.datetime.now()
today_str = session_start.strftime("%Y-%m-%d")
count = 1
rounds_completed = 0
daily_rounds = log_data.get(today_str, 0)

# === GUI Setup ===
root = tk.Tk()
root.title("🕉️ Japa Counter")
root.geometry("800x880")
root.configure(bg="#1e1e2f")

fonts = {
    "count": font.Font(family="Segoe UI", size=60, weight="bold"),
    "label": font.Font(family="Segoe UI", size=14),
    "header": font.Font(family="Segoe UI", size=20, weight="bold")
}

style = ttk.Style(root)
style.configure("TNotebook", background="#1e1e2f")
style.configure("TNotebook.Tab", padding=10, font=("Segoe UI", 12), background="#333", foreground="white")
style.map("TNotebook.Tab", background=[("selected", "#553388")])
style.configure("TButton", font=("Segoe UI", 11), padding=6)

notebook = ttk.Notebook(root)
notebook.pack(padx=10, pady=10, fill="both", expand=True)

# === COUNTER TAB ===
counter_tab = tk.Frame(notebook, bg="#1e1e2f")
notebook.add(counter_tab, text="📿 Counter")

tk.Label(counter_tab, text="✨ Hare Krishna ✨", font=fonts["header"], fg="#ffccff", bg="#1e1e2f").pack(pady=10)

ripple_canvas = tk.Canvas(counter_tab, bg="#1e1e2f", highlightthickness=0)
ripple_canvas.pack(fill="both", expand=True)

count_var = tk.IntVar(value=count)
label = tk.Label(ripple_canvas, textvariable=count_var, font=fonts["count"], fg="#99ffcc", bg="#1e1e2f")
label.place(relx=0.5, rely=0.3, anchor="center")

def pulse_label():
    colors = ['cc','bb','aa','99','88','77','88','99','aa','bb','cc']
    def step(i=0):
        if i >= len(colors):
            label.config(fg="#99ffcc")
            return
        label.config(fg=f"#99ff{colors[i]}")
        root.after(30, step, i + 1)
    step()

def ripple(x, y, max_radius=100, color="#99ffcc"):
    ripple_id = ripple_canvas.create_oval(x, y, x, y, outline=color)
    def expand(radius):
        if radius > max_radius:
            ripple_canvas.delete(ripple_id)
            return
        ripple_canvas.coords(ripple_id, x - radius, y - radius, x + radius, y + radius)
        root.after(16, expand, radius + 5)
    expand(0)

def update_bead_tracker():
    for i in range(108):
        bead_labels[i].config(bg="#3a3a3a")
    for i in range(count - 1):
        bead_labels[i].config(bg="#99ffcc")

def update_log():
    log_data[today_str] = daily_rounds
    with open(LOG_FILE, "w") as f:
        json.dump(log_data, f, indent=2)

def count_bead(x=None, y=None):
    global count, rounds_completed, daily_rounds
    count = count + 1 if count < 108 else 1
    if count == 1:
        rounds_completed += 1
        daily_rounds += 1
        rounds_var.set(f"🪔 Rounds This Session: {rounds_completed}")
        goal_var.set(f"📿 Today: {daily_rounds}/16")
        update_log()
    count_var.set(count)
    pulse_label()
    update_bead_tracker()
    ripple(x or 400, y or 260)

rounds_var = tk.StringVar(value=f"🪔 Rounds This Session: {rounds_completed}")
goal_var = tk.StringVar(value=f"📿 Today: {daily_rounds}/16")

tk.Label(ripple_canvas, textvariable=rounds_var, font=fonts["label"], fg="#66ccff", bg="#1e1e2f").place(relx=0.5, rely=0.45, anchor="center")
tk.Label(ripple_canvas, textvariable=goal_var, font=fonts["label"], fg="#ffcc66", bg="#1e1e2f").place(relx=0.5, rely=0.5, anchor="center")
ttk.Button(ripple_canvas, text="🕉️ Count Bead (Space)", command=count_bead).place(relx=0.5, rely=0.56, anchor="center")

def reset_counter():
    global count, rounds_completed
    count = 1
    rounds_completed = 0
    count_var.set(count)
    rounds_var.set("🪔 Rounds This Session: 0")
    update_bead_tracker()

ttk.Button(ripple_canvas, text="🔁 Reset Session", command=reset_counter).place(relx=0.5, rely=0.62, anchor="center")

bead_tracker_frame = tk.Frame(ripple_canvas, bg="#1e1e2f")
bead_tracker_frame.place(relx=0.5, rely=0.7, anchor="center")
bead_labels = []
for i in range(108):
    bead = tk.Label(bead_tracker_frame, width=1, height=1, bg="#3a3a3a", relief="flat")
    bead.grid(row=i//27, column=i%27, padx=1, pady=1)
    bead_labels.append(bead)

ripple_canvas.bind("<Button-1>", lambda e: count_bead(e.x, e.y))
root.bind("<space>", lambda e: count_bead())

# === CALENDAR TAB ===
calendar_tab = tk.Frame(notebook, bg="#1e1e2f")
notebook.add(calendar_tab, text="📅 Calendar Log")

month_summary_var = tk.StringVar()
tk.Label(calendar_tab, textvariable=month_summary_var, font=fonts["label"], fg="#ffffff", bg="#1e1e2f").pack(pady=10)

calendar_frame = tk.Frame(calendar_tab, bg="#1e1e2f")
calendar_frame.pack()

def show_day_summary(date_str):
    rounds = log_data.get(date_str, 0)
    messagebox.showinfo("📆 Day Summary", f"{date_str}: {rounds} rounds chanted.")

def refresh_calendar():
    for widget in calendar_frame.winfo_children():
        widget.destroy()
    now = datetime.datetime.now()
    year, month = now.year, now.month
    cal = calendar.monthcalendar(year, month)
    month_total = 0
    for week in cal:
        row = tk.Frame(calendar_frame, bg="#1e1e2f")
        row.pack()
        for day in week:
            if day == 0:
                tk.Label(row, text=" ", width=4, bg="#1e1e2f").pack(side="left")
            else:
                date_str = f"{year}-{month:02d}-{day:02d}"
                rounds = log_data.get(date_str, 0)
                month_total += rounds
                color = "#66ff66" if rounds > 0 else "#444"
                btn = tk.Button(row, text=str(day), width=4, fg="black", bg=color,
                    command=lambda d=date_str: show_day_summary(d))
                btn.pack(side="left")
    month_summary_var.set(f"🫘 Monthly Total: {month_total} rounds")

refresh_calendar()

# === STATS TAB ===
stats_tab = tk.Frame(notebook, bg="#1e1e2f")
notebook.add(stats_tab, text="📊 Stats")

tk.Label(stats_tab, text="📊 Your Chanting Stats", font=fonts["header"], fg="#ffcc99", bg="#1e1e2f").pack(pady=10)

total_rounds = sum(log_data.values())
days = len(log_data)
average = total_rounds // days if days > 0 else 0
best_day = max(log_data.items(), key=lambda x: x[1], default=("N/A", 0))

tk.Label(stats_tab, text=f"📦 Total Rounds: {total_rounds}", font=fonts["label"], fg="#66ccff", bg="#1e1e2f").pack(pady=5)
tk.Label(stats_tab, text=f"📈 Daily Average: {average}", font=fonts["label"], fg="#66ccff", bg="#1e1e2f").pack(pady=5)
tk.Label(stats_tab, text=f"🏆 Best Day: {best_day[0]} - {best_day[1]} rounds", font=fonts["label"], fg="#ffcc66", bg="#1e1e2f").pack(pady=5)

graph_frame = tk.Frame(stats_tab, bg="#1e1e2f")
graph_frame.pack(pady=10)

tk.Label(graph_frame, text="📅 Last 7 Days:", font=fonts["label"], fg="white", bg="#1e1e2f").pack()
graph_bar_frame = tk.Frame(graph_frame, bg="#1e1e2f")
graph_bar_frame.pack()

last_7 = []
today = datetime.date.today()
for i in range(6, -1, -1):
    date = (today - datetime.timedelta(days=i)).strftime("%Y-%m-%d")
    last_7.append((date, log_data.get(date, 0)))

max_val = max([v for _, v in last_7], default=1)
for date_str, val in last_7:
    bar = tk.Frame(graph_bar_frame, height=val * 5, width=20, bg="#99ffcc")
    bar.pack(side="left", padx=3, anchor="s")
    tk.Label(graph_bar_frame, text=date_str[-2:], fg="#aaa", bg="#1e1e2f").pack(side="left", padx=3)

# === Exit Handler ===
def on_exit():
    update_log()
    messagebox.showinfo("🙏 Japa Summary",
        f"You completed {rounds_completed} rounds this session.\n"
        f"Total today: {daily_rounds} rounds.\n\nHare Krishna!")
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_exit)

# === Run the App ===
root.mainloop()