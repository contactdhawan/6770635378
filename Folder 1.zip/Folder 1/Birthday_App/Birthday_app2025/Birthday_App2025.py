import tkinter as tk
import threading
import time
import random
import itertools

# Message formatted with line breaks preserved
message = """
🌸 Dear Mumma,

Happy Birthday! 🎉

On this special day, I want to express how truly grateful I am
to have you as my mother. This is my little attempt to show
just how happy and lucky I feel because of you.

You are so kind! You lift me up whenever I feel down, and you’re
always there when I need someone the most.

You are so brave! You help me face every challenge with strength,
and you always do your best to make me feel safe and happy.

Mumma, if I could give you even a fraction of the love and care
you've given me, I would consider myself blessed.

May Radha Krishna bless you with health, joy, and peace—
because you truly deserve nothing less.

With all my love,  
Anirudh 💖
"""

# Glowing pinks and soft romantic colors
glow_colors = [
    "#ff99cc", "#ff66b3", "#ffb6c1", "#ff69b4",
    "#fba0e3", "#fcb8d2", "#ffd6e7"
]

# Typewriter + glowing swirl
def typewriter_glow(canvas, message, x_start, y_start, line_spacing=32, delay=25):
    lines = message.strip().split("\n")
    font = ("Segoe Script", 16, "bold")

    def animate():
        for line_index, line in enumerate(lines):
            x = x_start
            y = y_start + line_index * line_spacing
            for char in line:
                if char == "\t":
                    x += 30
                    continue
                swirl_offset_x = random.randint(-1, 1)
                swirl_offset_y = random.randint(-1, 1)
                color = random.choice(glow_colors)

                letter = canvas.create_text(
                    x + swirl_offset_x,
                    y + swirl_offset_y,
                    text=char,
                    fill=color,
                    font=font,
                    anchor="nw"
                )

                animate_glow(canvas, letter)
                x += canvas.bbox(letter)[2] - canvas.bbox(letter)[0]
                time.sleep(delay / 1000)

    threading.Thread(target=animate).start()

# Letter glow effect
def animate_glow(canvas, item, speed=0.3):
    def glow():
        for color in itertools.cycle(glow_colors):
            try:
                canvas.itemconfig(item, fill=color)
                time.sleep(speed)
            except:
                break
    threading.Thread(target=glow, daemon=True).start()

# Falling petals
def animate_petals(canvas, width, height):
    flowers = ["❀", "✿", "🌸", "🌼"]
    petals = []

    for _ in range(30):
        x = random.randint(0, width)
        y = random.randint(-600, 0)
        flower = random.choice(flowers)
        petal = canvas.create_text(x, y, text=flower, font=("Arial", 16), fill="#ffc0cb")
        petals.append(petal)

    def fall():
        while True:
            for petal in petals:
                canvas.move(petal, 0, 6)
                pos = canvas.coords(petal)
                if pos[1] > height:
                    canvas.coords(petal, random.randint(0, width), -20)
            time.sleep(0.05)

    threading.Thread(target=fall, daemon=True).start()

# Main window
root = tk.Tk()
root.title("💖 A Magical Birthday Letter for Mumma 💖")
root.geometry("950x700")
root.configure(bg="#fff0f5")

# Canvas setup
canvas = tk.Canvas(root, width=950, height=700, bg="#fff0f5", highlightthickness=0)
canvas.pack()

# Start background petals
animate_petals(canvas, 950, 700)

# Launch glowing painted letter
typewriter_glow(canvas, message, x_start=60, y_start=60, delay=25)

root.mainloop()
