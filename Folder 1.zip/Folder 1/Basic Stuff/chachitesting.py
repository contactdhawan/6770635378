# print("hello")
# feeling = input("are you feeling sad or happy")
# name= input ("What is your name")
# message= ("hi "+ name)
# print (message)

# if feeling == ("happy"):
#     print("ohh nice")
# elif feeling == ("sad"):
#     print("go for a walk and liste to your favorite music you may feel better")
# else :
#     print("I don't know how to respond to that.")

print("This is a calculator. Which function would you like to use: addition, subtraction, multiplication, division, or exponent?")
functionmath = input()

x = int(input("What is the first number in the calculation? "))
y = int(input("What is the second number you would like to use in this calculation? "))

if functionmath == "addition":
    answer = x + y
    print("The answer is:", answer)
elif functionmath == "subtraction":
    answer = x - y
    print("The answer is:", answer)
elif functionmath == "multiplication":
    answer = x * y
    print("The answer is:", answer)
elif functionmath == "division":
    if y != 0:
        answer = x / y
        print("The answer is:", answer)
    else:
        print("Cannot divide by zero.")
elif functionmath == "exponent":
    answer = x ** y
    print("The answer is:", answer)
else:
    print("Unknown function")