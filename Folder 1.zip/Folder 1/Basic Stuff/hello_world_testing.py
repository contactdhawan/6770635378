print("Hello, World!")
feeling = input('How are you feeling today')
feeling = feeling.lower()
if feeling == "sad":
    print("I am sorry to hear about that")
elif feeling == "angry" or feeling == "upset":
    print("hjhfjdhfjdhfjdhfjdhjdh")
else : 
    print("I am happy to hear about that")

print("Hello World")
number1 = input('What is the first number you want to add')
number2 = input('What is the second number you want to add')
sum = int(number1) + int(number2)
print(sum)

print("Hello World")
name = input('What is your name? ')
namelength = len(name)
answer = "Your name contains " + str(namelength) + " letters"
print(answer)


musicInstruments = ["Viola", "Piano"]
counter = 1
for musicInstrument in musicInstruments:
    print(counter, musicInstrument)
    counter = counter + 1

