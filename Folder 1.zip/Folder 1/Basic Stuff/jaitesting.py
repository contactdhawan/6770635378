# # # print("Hello_world")
# # # print("what is your name")
# # # input_name = input()
# # # print("How are you doing, ", input_name, "?")
# # # print("How are you feeling happy, or sad")
# # # input_feeling = input()
# # # input_feeling = input_feeling.lower
# # # if input_feeling()[:1] == "happy":
# # #     print("Glad to hear that, have a nice day!")
# # # elif input_feeling()[:1] == "sad":
# # #     print("Sorry to hear that I hope this cheers you up. It is ok to be sad because sad stands for seacrtly a dino")
# # # else:
# # #     print("I don't understand mind you relaunch and try again")    

# # print("This is a calculator")
# # print("addition, subtraction, multiplication, division, or quit")
# # choice = input()
# # if choice == "addition":
# #     print("please enter first number")
# #     A = int(input())
# #     print("please enter second number")
# #     B = int(input())
# #     print("this is your awnser")
# #     C = A + B
# #     print(C)

# # elif choice == "subtraction":
# #     print("please enter first number")
# #     D = int(input())
# #     print("please enter second number")
# #     E = int(input())
# #     print("this is your awnser")
# #     F = D - E
# #     print(F)

# # elif choice == "multiplication":
# #     print("please enter first number")
# #     G = int(input())
# #     print("please enter second number")
# #     H = int(input())
# #     print("this is your awnser")
# #     I = G * H
# #     print(I)
# import sys

# def quit_program():
#     print("Quitting calculator")
#     sys.exit()

# while True:
#     print("Calculator")
#     print("Choose add, subtract, divide, multiply, or quit")
#     choice = input().lower()

#     if choice == "add":
#         print("Please enter first number")
#         A = int(input())
#         print("Please enter second number")
#         B = int(input())
#         print("Your answer is:")
#         print(A + B)

#     elif choice == "subtract":
#         print("Please enter first number")
#         A = int(input())
#         print("Please enter second number")
#         B = int(input())
#         print("Your answer is:")
#         print(A - B)

#     elif choice == "divide":
#         print("Please enter first number")
#         A = int(input())
#         print("Please enter second number")
#         B = int(input())
#         print("Your answer is:")
#         print(A / B)

#     elif choice == "multiply":
#         print("Please enter first number")
#         A = int(input())
#         print("Please enter second number")
#         B = int(input())
#         print("Your answer is:")
#         print(A * B)

#     elif choice == "quit":
#         quit_program()

#     else:
#         print("That is not a valid option.")
#         print("Valid options are: add, subtract, divide, multiply, quit")
# import tkinter as tk
# root = tk.Tk()
# root.geometry('1000x1000',)
# root.title("Test")

# tk.Canvas().pack()

# label = tk.Label(root, text="Hi bunny kind", font = ('Arial',90, "bold"), fg='red',bg='black' ).pack()
# button = tk.Button(root, text='Bunny', fg='red', bg='black', activeforeground='black', activebackground='red').pack(pady=20,padx=20)


# entry = tk.Entry(root, fg='red', bg='black', font = ('Arial', 90, 'bold'))
# entry.pack(pady=20,padx=20)

# root.mainloop()

# hi counter

# import tkinter as tk
# root = tk.Tk()

# counter = 0

# def click():
#     global counter
#     counter += 1
#     label.config(text=counter)


# button = tk.Button(root,text='hi', command=click)
# button.pack(pady=20)
# label = tk.Label(root, text=counter)
# label.pack(pady=20)

# root.mainloop()