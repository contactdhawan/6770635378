from tkinter import Tk, Canvas
from datetime import datetime
from zoneinfo import ZoneInfo  # Requires Python 3.9+

def getCurrentEvent(event_details):
    # Split the string into event name and datetime string
    current_event = event_details.split(',')
    # Parse the event datetime using the given format (day/month/year hour:minute)
    event_datetime = datetime.strptime(current_event[1], '%d/%m/%y %H:%M')
    # Attach the CST timezone (America/Chicago) if needed
    # event_datetime = event_datetime.replace(tzinfo=ZoneInfo("America/Chicago"))
    current_event[1] = event_datetime
    return current_event

def get_events():
    # Returns a list of events, each as [event name, event datetime]
    # Format: "Event Name,DD/MM/YY HH:MM"
    return [
        getCurrentEvent("Test Event,08/07/25 18:00"),
        getCurrentEvent("Test Event 2,08/07/25 18:30"),    
        getCurrentEvent("Test Event 3,08/07/25 17:30"),
        getCurrentEvent("Test Event 4,08/07/25 19:00"),
    ]

def get_time_left(future_datetime, now_datetime):
    # Calculate the time difference between now and the event
    print(future_datetime, now_datetime)
    delta = future_datetime - now_datetime
    seconds_left = delta.total_seconds()
    if seconds_left < 0:
        # Event has already passed
        return "Event Passed", "gray"
    hours = int(seconds_left / 3600)
    minutes = int((seconds_left % 3600) // 60)

    # Determine the color based on hours left
    if hours >= 5:
        color = "lightgreen"
    elif 3 <= hours < 5:
        color = "yellow"
    else:
        color = "red"

    return f"{hours} hrs {minutes} mins", color

# Setup the main GUI window
root = Tk()
c = Canvas(root, width=1500, height=1500, bg='black')
c.pack()

# Title text (unchanged design)
c.create_text(
    100, 50, anchor='w', fill='orange', font='Arial 28 bold underline',
    text='Blooket Live Countdown Calendar for SG Tournaments'
)

# Retrieve events and initialize canvas text items for each event
events = get_events()
text_items = []
start_y = 100
for i in range(len(events)):
    # Create a text item for each event countdown
    text_item = c.create_text(
        100, start_y + i * 40, anchor='w', fill='lightblue',
        font='Arial 28 bold', text=''
    )
    text_items.append(text_item)

def update_countdowns():
    # Update the countdown timers for each event
    now = datetime.now()
    print("Current time:", now)
    for i, event in enumerate(events):
        name = event[0]
        event_time = event[1]
        time_left_str, color = get_time_left(event_time, now)
        # Update the canvas text with the new countdown and color
        c.itemconfig(text_items[i], text=f"It is {time_left_str} until {name}", fill=color)
    # Schedule the next update in 1 second (1000 ms)
    root.after(1000, update_countdowns)

# Start the countdown updates
update_countdowns()
# Run the Tkinter event loop
root.mainloop()