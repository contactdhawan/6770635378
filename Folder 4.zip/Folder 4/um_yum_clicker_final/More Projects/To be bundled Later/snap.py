import random
import time
from tkinter import Tk, Canvas, Button, HIDDEN, NORMAL

try:
    import numpy as np
except ImportError:
    import sys
    print("This game requires numpy. Please run: pip install numpy")
    sys.exit(1)

try:
    import winsound
    def beep(freq, dur):
        winsound.Beep(freq, dur)
except ImportError:
    def beep(freq, dur):
        pass  # No sound on non-Windows

root = Tk()
root.title('Snap')
c = Canvas(root, width=400, height=450)
c.pack()

colors = ['black', 'red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'cyan', 'brown']

# --- Drawing helpers ---

def hex_to_rgb(color):
    return c.winfo_rgb(color)

def draw_gradient_rect(canvas, x1, y1, x2, y2, color1, color2, steps=50, state=HIDDEN):
    r1, g1, b1 = hex_to_rgb(color1)
    r2, g2, b2 = hex_to_rgb(color2)
    r_ratio = (r2 - r1) / steps
    g_ratio = (g2 - g1) / steps
    b_ratio = (b2 - b1) / steps
    height = y2 - y1
    ids = []
    for i in range(steps):
        nr = int(r1 + (r_ratio * i)) >> 8
        ng = int(g1 + (g_ratio * i)) >> 8
        nb = int(b1 + (b_ratio * i)) >> 8
        color = f'#{nr:02x}{ng:02x}{nb:02x}'
        y = y1 + int((i / steps) * height)
        rect_id = canvas.create_rectangle(x1, y, x2, y + height // steps + 1, outline=color, fill=color, state=state)
        ids.append(rect_id)
    return ids

def draw_gradient_oval(canvas, x1, y1, x2, y2, color1, color2, steps=50, state=HIDDEN):
    r1, g1, b1 = hex_to_rgb(color1)
    r2, g2, b2 = hex_to_rgb(color2)
    r_ratio = (r2 - r1) / steps
    g_ratio = (g2 - g1) / steps
    b_ratio = (b2 - b1) / steps
    ids = []
    for i in range(steps):
        nr = int(r1 + (r_ratio * i)) >> 8
        ng = int(g1 + (g_ratio * i)) >> 8
        nb = int(b1 + (b_ratio * i)) >> 8
        color = f'#{nr:02x}{ng:02x}{nb:02x}'
        pad = int(i * ((x2 - x1) / (2 * steps)))
        oval_id = canvas.create_oval(x1 + pad, y1 + pad, x2 - pad, y2 - pad, outline=color, fill=color, state=state)
        ids.append(oval_id)
    return ids

def draw_gradient_polygon(canvas, points, color1, color2, steps=50, state=HIDDEN):
    points = np.array(points).reshape(-1, 2)
    center = points.mean(axis=0)
    ids = []
    r1, g1, b1 = hex_to_rgb(color1)
    r2, g2, b2 = hex_to_rgb(color2)
    r_ratio = (r2 - r1) / steps
    g_ratio = (g2 - g1) / steps
    b_ratio = (b2 - b1) / steps
    for i in range(steps):
        nr = int(r1 + (r_ratio * i)) >> 8
        ng = int(g1 + (g_ratio * i)) >> 8
        nb = int(b1 + (b_ratio * i)) >> 8
        color = f'#{nr:02x}{ng:02x}{nb:02x}'
        scale = 1 - (i / (steps * 1.2))
        scaled_points = (points - center) * scale + center
        poly_id = canvas.create_polygon(*scaled_points.flatten(), outline=color, fill=color, state=state)
        ids.append(poly_id)
    return ids

def is_solid(shape_type):
    return shape_type.endswith('_solid')

def base_shape_type(shape_type):
    if shape_type.endswith('_solid'):
        return shape_type[:-6]
    elif shape_type.endswith('_gradient'):
        return shape_type[:-9]
    return shape_type

# --- Game logic ---

def create_shapes():
    shapes = []
    for color in colors:
        ids = draw_gradient_oval(c, 35, 20, 365, 350, color, "white")
        shapes.append(('circle_gradient', color, ids))
        solid_id = c.create_oval(35, 20, 365, 350, outline=color, fill=color, state=HIDDEN)
        shapes.append(('circle_solid', color, [solid_id]))
    for color in colors:
        ids = draw_gradient_rect(c, 35, 100, 365, 270, color, "white")
        shapes.append(('rectangle_gradient', color, ids))
        solid_id = c.create_rectangle(35, 100, 365, 270, outline=color, fill=color, state=HIDDEN)
        shapes.append(('rectangle_solid', color, [solid_id]))
    for color in colors:
        ids = draw_gradient_rect(c, 100, 100, 300, 300, color, "white")
        shapes.append(('square_gradient', color, ids))
        solid_id = c.create_rectangle(100, 100, 300, 300, outline=color, fill=color, state=HIDDEN)
        shapes.append(('square_solid', color, [solid_id]))
    for color in colors:
        ids = draw_gradient_polygon(
            c,
            [200, 40, 360, 340, 40, 340],
            color, "white"
        )
        shapes.append(('triangle_gradient', color, ids))
        solid_id = c.create_polygon(200, 40, 360, 340, 40, 340, outline=color, fill=color, state=HIDDEN)
        shapes.append(('triangle_solid', color, [solid_id]))
    for color in colors:
        ids = draw_gradient_polygon(
            c,
            [200, 30, 350, 120, 350, 280, 200, 370, 50, 280, 50, 120],
            color, "white"
        )
        shapes.append(('hexagon_gradient', color, ids))
        solid_id = c.create_polygon(
            200, 30, 350, 120, 350, 280, 200, 370, 50, 280, 50, 120,
            outline=color, fill=color, state=HIDDEN)
        shapes.append(('hexagon_solid', color, [solid_id]))
    return shapes

def reset_game_state():
    global shapes, current_shape, previous_shape_type, previous_shape_color
    global current_shape_type, current_shape_color, player1_score, player2_score
    global player1_passed, player2_passed, round_num, total_rounds, timer_id, time_left
    shapes = create_shapes()
    random.shuffle(shapes)
    current_shape = None
    previous_shape_type = ''
    previous_shape_color = ''
    current_shape_type = ''
    current_shape_color = ''
    player1_score = 0
    player2_score = 0
    player1_passed = False
    player2_passed = False
    round_num = 0
    total_rounds = len(shapes)
    time_left = 5
    c.delete("all")
    update_score()
    update_round()
    update_timer(5)

def display_winner():
    if player1_score > player2_score:
        c.create_text(200, 200, text='Winner : Player 1!', font=('Arial', 20), tags="winner")
    elif player1_score < player2_score:
        c.create_text(200, 200, text='Winner : Player 2!', font=('Arial', 20), tags="winner")
    else:
        c.create_text(200, 200, text='Draw', font=('Arial', 20), tags="winner")
    show_restart_button()

def hide_shape(shape_ids):
    for sid in shape_ids:
        c.itemconfigure(sid, state=HIDDEN)

def show_shape(shape_ids):
    for sid in shape_ids:
        c.itemconfigure(sid, state=NORMAL)
    c.update()  # Force canvas update

def update_score():
    c.delete("score")
    c.create_text(80, 420, text=f"P1: {player1_score}", font=('Arial', 14), fill="blue", tags="score")
    c.create_text(320, 420, text=f"P2: {player2_score}", font=('Arial', 14), fill="red", tags="score")
    c.tag_raise("score")

def update_round():
    c.delete("round")
    c.create_text(200, 420, text=f"Round: {round_num}/{total_rounds}", font=('Arial', 14), tags="round")
    c.tag_raise("round")

def update_timer(t):
    c.delete("timer")
    c.create_text(200, 440, text=f"Time left: {t}s", font=('Arial', 12), tags="timer")
    c.tag_raise("timer")

def draw_instructions():
    c.create_text(200, 30, text="Snap Game!", font=('Arial', 18, 'bold'))
    c.create_text(200, 55, text="Q: Snap (P1)  P: Snap (P2)  A: Pass (P1)  L: Pass (P2)", font=('Arial', 10))
    c.create_text(200, 75, text="Only solid shapes of same type and color snap!", font=('Arial', 10), fill="gray")

def show_restart_button():
    restart_btn = Button(root, text="Restart", font=('Arial', 12), command=restart_game)
    restart_btn.place(x=170, y=390)
    c.restart_btn = restart_btn

def hide_restart_button():
    if hasattr(c, 'restart_btn'):
        c.restart_btn.destroy()
        del c.restart_btn

def next_shape():
    global current_shape, previous_shape_type, previous_shape_color, current_shape_type, current_shape_color, player1_passed, player2_passed, round_num, time_left, timer_id
    if current_shape is not None:
        hide_shape(current_shape)
    previous_shape_type = current_shape_type
    previous_shape_color = current_shape_color
    player1_passed = False
    player2_passed = False
    if len(shapes) > 0:
        shape_type, color, shape_ids = shapes.pop()
        current_shape = shape_ids
        current_shape_type = shape_type
        current_shape_color = color
        show_shape(current_shape)
        round_num += 1
        update_score()
        update_round()
        time_left = 5
        update_timer(time_left)
        draw_instructions()  # Draw instructions after shape is shown
        timer_id = root.after(1000, countdown)
    else:
        c.delete("timer")
        c.delete("round")
        display_winner()

def countdown():
    global time_left, timer_id
    time_left -= 1
    update_timer(time_left)
    if time_left <= 0:
        beep(400, 200)
        auto_pass()
    else:
        timer_id = root.after(1000, countdown)

def auto_pass():
    global player1_passed, player2_passed
    player1_passed = True
    player2_passed = True
    if current_shape is not None:
        hide_shape(current_shape)
    next_shape()

def snap(event):
    global current_shape, player1_score, player2_score, player1_passed, player2_passed
    global previous_shape_type, previous_shape_color, current_shape_type, current_shape_color, timer_id
    key = event.char.lower()
    valid = False
    if key == 'q' or key == 'p':
        if current_shape is not None:
            hide_shape(current_shape)
        # Only snap if both are solids, same base shape, and same color
        if (is_solid(previous_shape_type) and is_solid(current_shape_type) and
            base_shape_type(previous_shape_type) == base_shape_type(current_shape_type) and
            previous_shape_color == current_shape_color and
            previous_shape_type != '' and previous_shape_color != ''):
            valid = True
        if valid:
            beep(800, 100)
            if key == 'q':
                player1_score += 1
            else:
                player2_score += 1
            msg = 'SNAP! You score 1 point!'
        else:
            beep(200, 200)
            if key == 'q':
                player1_score -= 1
            else:
                player2_score -= 1
            msg = 'Wrong! You lose 1 point!'
        c.delete("msg")
        temp_text = c.create_text(200, 200, text=msg, font=('Arial', 14), tags="msg")
        update_score()
        root.update_idletasks()
        if 'timer_id' in globals():
            root.after_cancel(timer_id)
        root.after(1200, lambda: (c.delete(temp_text), next_shape()))
    elif key == 'a':
        player1_passed = True
    elif key == 'l':
        player2_passed = True

    if player1_passed and player2_passed:
        if current_shape is not None:
            hide_shape(current_shape)
        if 'timer_id' in globals():
            root.after_cancel(timer_id)
        next_shape()

def setup_controls():
    c.bind('q', snap)
    c.bind('p', snap)
    c.bind('a', snap)
    c.bind('l', snap)
    c.focus_set()

def restart_game():
    hide_restart_button()
    reset_game_state()
    root.after(1000, next_shape)

# --- Main game start ---
reset_game_state()
setup_controls()
root.after(1000, next_shape)
root.mainloop()