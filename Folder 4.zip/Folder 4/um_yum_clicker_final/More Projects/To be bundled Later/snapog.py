import random
import time
from tkinter import Tk, Canvas, HIDDEN, NORMAL

def next_shape():
    global shape, previous_color, current_color
    global player1_skipped, player2_skipped

    previous_color = current_color
    player1_skipped = False
    player2_skipped = False

    if shape is not None:
        c.delete(shape)
    if len(shapes) > 0:
        shape = shapes.pop()
        c.itemconfigure(shape, state=NORMAL)
        current_color = c.itemcget(shape, 'fill')
    else:
        c.unbind('q')
        c.unbind('p')
        c.unbind('a')
        c.unbind('l')
        if player1_score > player2_score:
            c.create_text(200, 200, text='Winner: Player 1')
        elif player2_score > player1_score:
            c.create_text(200, 200, text='Winner: Player 2')
        else:
            c.create_text(200, 200, text='Draw')
        c.pack()

def snap(event):
    global shape, player1_score, player2_score, previous_color
    global player1_skipped, player2_skipped

    valid = False

    if event.char == 'q' or event.char == 'p':
        c.delete(shape)
        if previous_color == current_color:
            valid = True

        if valid:
            if event.char == 'q':
                player1_score += 1
            else:
                player2_score += 1
            shape = c.create_text(200, 200, text='SNAP! You score 1 point!')
        else:
            if event.char == 'q':
                player1_score -= 1
            else:
                player2_score -= 1
            shape = c.create_text(200, 200, text='WRONG! You lose 1 point!')
        c.pack()
        root.update_idletasks()
        time.sleep(1)
    elif event.char == 'a':
        player1_skipped = True
    elif event.char == 'l':
        player2_skipped = True

    # Only skip if both players have pressed their skip key
    if player1_skipped and player2_skipped:
        player1_skipped = False
        player2_skipped = False
        next_shape()

def create_shapes():
    shape_ids = []
    # Expanded color list
    colors = [
        'black', 'red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink',
        'cyan', 'brown', 'magenta', 'lime', 'navy', 'gold', 'teal'
    ]
    # Circles
    for color in colors:
        shape_ids.append(c.create_oval(35, 20, 365, 350, outline=color, fill=color, state=HIDDEN))
    # Rectangles
    for color in colors:
        shape_ids.append(c.create_rectangle(35, 100, 365, 270, outline=color, fill=color, state=HIDDEN))
    # Squares
    for color in colors:
        shape_ids.append(c.create_rectangle(100, 100, 300, 300, outline=color, fill=color, state=HIDDEN))
    # Triangles
    for color in colors:
        shape_ids.append(c.create_polygon(200, 40, 360, 340, 40, 340, outline=color, fill=color, state=HIDDEN))
    # Hexagons
    for color in colors:
        shape_ids.append(c.create_polygon(
            200, 30, 350, 120, 350, 280, 200, 370, 50, 280, 50, 120,
            outline=color, fill=color, state=HIDDEN))
    # Diamonds
    for color in colors:
        shape_ids.append(c.create_polygon(
            200, 60, 340, 200, 200, 340, 60, 200,
            outline=color, fill=color, state=HIDDEN))
    return shape_ids

root = Tk()
root.title('Snap')
c = Canvas(root, width=400, height=400)
c.pack()

shapes = create_shapes()
random.shuffle(shapes)

shape = None
previous_color = 'a'
current_color = 'b'
player1_score = 0
player2_score = 0
player1_skipped = False
player2_skipped = False

root.after(1000, next_shape)
c.bind('q', snap)
c.bind('p', snap)
c.bind('a', snap)
c.bind('l', snap)
c.focus_set()
root.mainloop()