import tkinter as tk
from tkinter import HIDDEN, NORMAL
from textblob import TextBlob
import random, time, datetime

# --- Personalization & Mood State ---
Username = input("What is your name?  ")
message="Thank you"+ Username
print(message)
print("The controls are 'd' for pet, 'j' for emotional journal, and space for color change."
      " Make sure you have clicked on the window before doing these commands!")
USERNAME = 'Username'
AFFECTION = 0
ENERGY = 100  # Out of 100
MOOD_STATE = "neutral"  # Can be 'neutral', 'playful', 'sleepy', 'shy', 'affectionate'
last_interaction = time.time()
hover_timer_id = None
current_color = "light salmon"
color_theme = "day"

# --- Color Themes ---
BUNNY_COLORS = [
    "light salmon", "light sky blue", "plum1", "light goldenrod",
    "pale turquoise", "misty rose", "lavender blush"
]
BACKGROUND_THEMES = {
    "day": "light blue",
    "evening": "light steel blue",
    "night": "midnight blue"
}

# --- Daily Schedule ---
BUNNY_SCHEDULE = {
    "07:00": "wake_up",
    "09:00": "morning_boost",
    "12:00": "lunch_nudge",
    "15:00": "stretch_reminder",
    "18:00": "wind_down",
    "22:00": "bedtime"
}

# --- Mood Log ---
MOOD_LOG = {"happy": 0, "sad": 0, "cheeky": 0, "neutral": 0, "sleepy": 0, "affectionate": 0}

# --- Bunny Dialogues ---
dialogues = {
    "happy": [
        "You're back!! 🐾", "That made my whiskers wiggle!", "Fluffy joy levels rising!"
    ],
    "sad": [
        "I waited... and waited...", "Was I forgotten?", "*small sniffle*"
    ],
    "cheeky": [
        "Hehe! Gotcha!", "Surprise boop attack!", "Poke poke poke!"
    ],
    "neutral": [
        "Just chilling... bunny style.", "Watching clouds in my mind.", "Still cute. Always cute."
    ],
    "sleepy": [
        "I feel... snoozy... 💤", "Nap o'clock?", "*gentle yawn*"
    ],
    "affectionate": [
        "You mean the world to me 💙", "Can I stay close a bit longer?", "*snuggles up virtually*"
    ],
    "wake_up": ["Yawwwwn... morning already?", "Let’s start hopping!"],
    "morning_boost": ["Let’s bounce through this day!", "You're unstoppable this morning!"],
    "lunch_nudge": ["Carrot break?", "I hereby declare it snack o’clock 🥕"],
    "stretch_reminder": ["Stretch those paws!", "Flop, stretch, repeat."],
    "wind_down": ["Wanna talk about your day?", "It’s cozy hour now."],
    "bedtime": ["Tuck me in?", "Goodnight, glowing star."]
}

# --- Window Setup ---
root = tk.Tk()
WIDTH, HEIGHT = 400, 500
root.geometry(f"{WIDTH}x{HEIGHT}+40+40")
root.title("Bunny Companion")
root.wm_attributes("-topmost", True)
root.resizable(False, False)

# --- Canvas Setup ---
c = tk.Canvas(root, width=WIDTH, height=400, bg=BACKGROUND_THEMES["day"], highlightthickness=0)
c.pack()

# --- Drawing Function ---
def draw_bunny(color):
    c.delete("all")
    c.body_color = color

    # --- HEAD ---
    c.head = c.create_oval(130, 60, 270, 180, fill=color, outline=color)

    # --- BODY ---
    c.body = c.create_oval(100, 120, 300, 300, fill=color, outline=color)

    # --- EARS ---
    c.ear_left = c.create_polygon(160, 60, 150, 10, 190, 50, fill=color, outline=color)
    c.ear_right = c.create_polygon(240, 50, 260, 10, 270, 60, fill=color, outline=color)
    c.ear_inner_left = c.create_polygon(165, 55, 158, 15, 187, 47, fill="pink", outline="")
    c.ear_inner_right = c.create_polygon(245, 47, 255, 15, 265, 55, fill="pink", outline="")

    # --- TAIL ---
    c.tail = c.create_oval(85, 220, 115, 250, fill="white", outline="white")

    # --- PAWS (FRONT) ---
    c.paw_left = c.create_oval(145, 240, 165, 260, fill=color, outline=color)
    c.paw_right = c.create_oval(235, 240, 255, 260, fill=color, outline=color)
    c.paw_pad_left = c.create_oval(152, 248, 158, 254, fill="pink", outline="")
    c.paw_pad_right = c.create_oval(242, 248, 248, 254, fill="pink", outline="")

    # --- FEET ---
    c.foot_left = c.create_oval(135, 280, 180, 305, fill=color, outline=color)
    c.foot_right = c.create_oval(220, 280, 265, 305, fill=color, outline=color)
    c.pad_left = c.create_oval(150, 290, 160, 300, fill="pink", outline="")
    c.pad_right = c.create_oval(240, 290, 250, 300, fill="pink", outline="")

    # --- FACE ---
    c.eye_left = c.create_oval(170, 115, 185, 130, fill="white")
    c.eye_right = c.create_oval(215, 115, 230, 130, fill="white")
    c.pupil_left = c.create_oval(176, 121, 180, 125, fill="black")
    c.pupil_right = c.create_oval(221, 121, 225, 125, fill="black")
    c.glint_left = c.create_oval(177, 120, 178, 121, fill="white")
    c.glint_right = c.create_oval(222, 120, 223, 121, fill="white")

    c.nose = c.create_polygon(198, 135, 202, 135, 200, 139, fill="pink", outline="")
    c.cheek_left = c.create_oval(160, 130, 170, 140, fill="misty rose", state=HIDDEN)
    c.cheek_right = c.create_oval(230, 130, 240, 140, fill="misty rose", state=HIDDEN)

    c.mouth_normal = c.create_line(190, 142, 200, 146, 210, 142, smooth=True, width=2)
    c.mouth_happy = c.create_line(190, 142, 200, 150, 210, 142, smooth=True, width=2, state=HIDDEN)
    c.mouth_sad = c.create_line(190, 142, 200, 136, 210, 142, smooth=True, width=2, state=HIDDEN)
    c.tongue_main = c.create_rectangle(190, 146, 210, 158, fill="red", state=HIDDEN)
    c.tongue_tip = c.create_oval(190, 156, 210, 164, fill="red", state=HIDDEN)

# --- Dialogue Output ---
speech = tk.Label(root, text="", bg=c["bg"], fg="white", font=("Comic Sans MS", 11, 'bold'))
speech.pack()
entry = tk.Entry(root, width=36)
entry.pack(pady=4)

def say(mood):
    global AFFECTION, MOOD_STATE, last_interaction
    last_interaction = time.time()
    if mood not in dialogues:
        mood = "neutral"
    line = random.choice(dialogues[mood])
    speech.config(text=line)
    if mood == "happy":
        AFFECTION += 1
        MOOD_STATE = "playful"
    elif mood == "affectionate":
        AFFECTION += 2
        MOOD_STATE = "affectionate"
    elif mood == "sad":
        AFFECTION = max(0, AFFECTION - 1)
        MOOD_STATE = "shy"
    elif mood == "sleepy":
        MOOD_STATE = "sleepy"
    else:
        MOOD_STATE = "neutral"
    MOOD_LOG[mood] = MOOD_LOG.get(mood, 0) + 1

def analyze_sentiment():
    text = entry.get()
    if not text.strip():
        return
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    if "love" in text.lower():
        say("affectionate"); poke_cheeks()
    elif "bye" in text.lower() or "goodnight" in text.lower():
        nap()
    elif polarity > 0.3:
        say("happy"); wiggle_ears()
    elif polarity < -0.3:
        say("sad")
    else:
        say("neutral")

tk.Button(root, text="Talk to Bunny 💬", command=analyze_sentiment).pack()

# --- Mood Animation Helpers ---
def poke_cheeks():
    c.itemconfigure(c.cheek_left, state=NORMAL)
    c.itemconfigure(c.cheek_right, state=NORMAL)
    root.after(800, lambda: (
        c.itemconfigure(c.cheek_left, state=HIDDEN),
        c.itemconfigure(c.cheek_right, state=HIDDEN)
    ))

def wiggle_ears():
    c.move(c.ear_left, -3, -2)
    c.move(c.ear_right, 3, -2)
    root.after(200, lambda: (
        c.move(c.ear_left, 3, 2),
        c.move(c.ear_right, -3, 2)
    ))

def wiggle_feet():
    for i in range(2):
        root.after(i * 200, lambda: (
            c.move(c.foot_left, -2, 0),
            c.move(c.foot_right, 2, 0)
        ))
        root.after(i * 200 + 100, lambda: (
            c.move(c.foot_left, 2, 0),
            c.move(c.foot_right, -2, 0)
        ))

def nap():
    say("sleepy")
    c.itemconfigure(c.mouth_normal, state=HIDDEN)
    c.itemconfigure(c.mouth_happy, state=HIDDEN)
    c.itemconfigure(c.mouth_sad, state=NORMAL)
    speech.config(text="Zzz... bunny nap... 💤")

def pet_bunny(event=None):
    say("affectionate")
    poke_cheeks()
    wiggle_ears()

def dance_party(event=None):
    say("cheeky")
    wiggle_feet()
    poke_cheeks()
    c.itemconfigure(c.tongue_main, state=NORMAL)
    c.itemconfigure(c.tongue_tip, state=NORMAL)
    root.after(1000, lambda: (
        c.itemconfigure(c.tongue_main, state=HIDDEN),
        c.itemconfigure(c.tongue_tip, state=HIDDEN)
    ))

# --- Time-Based Greetings ---
def greet_by_time():
    hour = datetime.datetime.now().hour
    if 6 <= hour < 12:
        say("morning_boost")
    elif 12 <= hour < 18:
        say("lunch_nudge")
    elif 18 <= hour < 22:
        say("wind_down")
    else:
        say("bedtime")

# --- Scheduled Events Check ---
def follow_schedule():
    now = datetime.datetime.now().strftime("%H:%M")
    if now in BUNNY_SCHEDULE:
        mood = BUNNY_SCHEDULE[now]
        if mood in dialogues:
            say(mood)
    root.after(60000, follow_schedule)  # Check every minute

# --- Idle Reactions ---
def idle_muse():
    if time.time() - last_interaction > 25:
        say("neutral")
    if time.time() - last_interaction > 50:
        say("musing")
    root.after(15000, idle_muse)

# --- Mood Pulse ---
def mood_decay():
    global ENERGY, MOOD_STATE
    ENERGY = max(0, ENERGY - 1)
    if ENERGY < 30 and MOOD_STATE != "sleepy":
        say("sleepy")
    elif ENERGY > 80 and AFFECTION > 10 and MOOD_STATE != "affectionate":
        say("affectionate")
    elif ENERGY < 60 and AFFECTION < 3:
        say("sad")
    root.after(30000, mood_decay)

# --- Mood Journal ---
def emotion_journal(event=None):
    print("\n📘 Bunny Emotion Journal:")
    for mood, count in MOOD_LOG.items():
        print(f"• {mood.title():<12}: {count}")
    print(f"❤️ Affection Level: {AFFECTION}")
    print(f"⚡ Energy: {ENERGY}")
    print(f"🎭 Mood State: {MOOD_STATE}\n")

# --- Event Bindings ---
def change_color(event=None):
    global current_color
    new_color = random.choice([col for col in BUNNY_COLORS if col != current_color])
    current_color = new_color
    draw_bunny(current_color)
    say("happy")

# --- Eye Blink Cycle ---
def toggle_eyes():
    fill = c.body_color if c.itemcget(c.eye_left, 'fill') == 'white' else 'white'
    state = HIDDEN if c.itemcget(c.pupil_left, 'state') == NORMAL else NORMAL
    c.itemconfigure(c.eye_left, fill=fill)
    c.itemconfigure(c.eye_right, fill=fill)
    c.itemconfigure(c.pupil_left, state=state)
    c.itemconfigure(c.pupil_right, state=state)

def blink():
    toggle_eyes()
    root.after(250, toggle_eyes)
    root.after(random.randint(4000, 7000), blink)

# --- Breathing Animation (gentle body pulsing) ---
def breathe():
    c.scale(c.body, 200, 200, 1.005, 1.005)
    c.scale(c.head, 200, 200, 1.003, 1.003)
    root.after(1000, lambda: (
        c.scale(c.body, 200, 200, 0.995, 0.995),
        c.scale(c.head, 200, 200, 0.997, 0.997)
    ))
    root.after(2000, breathe)

# --- Input Hooks ---
c.bind("<Button-1>", pet_bunny)
root.bind("<space>", change_color)
root.bind("d", dance_party)
root.bind("j", emotion_journal)

# --- Startup Sequence ---
draw_bunny(current_color)
greet_by_time()
blink()
breathe()
follow_schedule()
idle_muse()
mood_decay()
root.mainloop()