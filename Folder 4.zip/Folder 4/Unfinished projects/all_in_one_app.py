import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import math, webbrowser, os, tempfile

# ===== App Setup =====
root = tk.Tk()
root.title("All-in-One Toolbox")
root.geometry("900x600")
notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

# ===== Global Colors =====
COLORS = {
    "Calculator": "#f0f8ff",
    "Translator": "#fff0f5",
    "Notes": "#f5fff0",
    "CodeRunner": "#f0f0ff"
}

# ===== CALCULATOR TAB =====
calc_frame = tk.Frame(notebook, bg=COLORS["Calculator"])
notebook.add(calc_frame, text="🧮 Calculator")

calc_entry = tk.Entry(calc_frame, font=("Consolas", 20), justify='right')
calc_entry.pack(fill='x', padx=10, pady=10)

history = []

def calculate():
    expr = calc_entry.get()
    try:
        result = eval(expr, {"__builtins__": None}, math.__dict__)
        history.append(f"{expr} = {result}")
        calc_result.config(text=f"= {result}")
    except Exception as e:
        calc_result.config(text="Error")

def show_history():
    messagebox.showinfo("History", "\n".join(history[-10:]))

btn_frame = tk.Frame(calc_frame, bg=COLORS["Calculator"])
btn_frame.pack()

buttons = [
    "7", "8", "9", "/", "sin",
    "4", "5", "6", "*", "cos",
    "1", "2", "3", "-", "tan",
    "0", ".", "(", ")", "+",
    "sqrt", "log", "pi", "e", "CLR"
]

def on_click(val):
    if val == "CLR":
        calc_entry.delete(0, 'end')
        calc_result.config(text="")
    elif val in ["sin", "cos", "tan", "sqrt", "log"]:
        calc_entry.insert(tk.END, f"{val}(")
    elif val in ["pi", "e"]:
        calc_entry.insert(tk.END, f"math.{val}")
    else:
        calc_entry.insert(tk.END, val)

for i, b in enumerate(buttons):
    tk.Button(btn_frame, text=b, width=6, height=2,
              command=lambda val=b: on_click(val)).grid(row=i//5, column=i%5)

tk.Button(calc_frame, text="Calculate", command=calculate).pack(pady=5)
tk.Button(calc_frame, text="History", command=show_history).pack()
calc_result = tk.Label(calc_frame, text="", font=("Arial", 18), bg=COLORS["Calculator"])
calc_result.pack(pady=10)

# ===== TRANSLATOR TAB =====
trans_frame = tk.Frame(notebook, bg=COLORS["Translator"])
notebook.add(trans_frame, text="🔤 Translator")

tk.Label(trans_frame, text="Nāltëka → English", font=("Arial", 16), bg=COLORS["Translator"]).pack(pady=10)
nal_input = tk.Text(trans_frame, height=5, font=("Consolas", 14))
nal_input.pack(padx=10, pady=5, fill='x')

trans_output = tk.Text(trans_frame, height=5, font=("Consolas", 14), bg="#e8f4ff")
trans_output.pack(padx=10, pady=5, fill='x')

dictionary = {
    "kalu": "hello", "ven": "friend", "rak": "light", "mira": "peace",
    "lor": "and", "zun": "you", "tal": "are", "feru": "strong"
}

def translate():
    words = nal_input.get("1.0", "end-1c").strip().split()
    translated = [dictionary.get(w, f"[{w}]") for w in words]
    trans_output.delete("1.0", tk.END)
    trans_output.insert(tk.END, " ".join(translated))

tk.Button(trans_frame, text="Translate", command=translate).pack(pady=10)

# ===== NOTES TAB =====
notes_frame = tk.Frame(notebook, bg=COLORS["Notes"])
notebook.add(notes_frame, text="📝 Notes")

note_text = tk.Text(notes_frame, font=("Consolas", 14), wrap='word')
note_text.pack(fill='both', expand=True, padx=10, pady=10)

def save_note():
    f = filedialog.asksaveasfile(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
    if f:
        f.write(note_text.get("1.0", tk.END))
        f.close()

def load_note():
    f = filedialog.askopenfile(filetypes=[("Text files", "*.txt")])
    if f:
        note_text.delete("1.0", tk.END)
        note_text.insert(tk.END, f.read())
        f.close()

tk.Button(notes_frame, text="Save", command=save_note).pack(side='left', padx=10, pady=5)
tk.Button(notes_frame, text="Load", command=load_note).pack(side='left', pady=5)

# ===== CODE RUNNER TAB =====
code_frame = tk.Frame(notebook, bg=COLORS["CodeRunner"])
notebook.add(code_frame, text="💻 Code Runner")

lang_tabs = ttk.Notebook(code_frame)
lang_tabs.pack(fill='both', expand=True)

# -- Python Runner --
py_tab = tk.Frame(lang_tabs, bg="#eef")
lang_tabs.add(py_tab, text="Python")

py_input = tk.Text(py_tab, height=10, font=("Consolas", 13))
py_input.pack(fill='x', padx=10, pady=5)

py_output = tk.Text(py_tab, height=10, font=("Consolas", 13), bg="#ddf")
py_output.pack(fill='both', expand=True, padx=10, pady=5)

def run_python():
    py_output.delete("1.0", tk.END)
    code = py_input.get("1.0", tk.END)
    try:
        local_vars = {}
        exec(code, {}, local_vars)
        for key, val in local_vars.items():
            py_output.insert(tk.END, f"{key} = {val}\n")
    except Exception as e:
        py_output.insert(tk.END, str(e))

tk.Button(py_tab, text="Run Python", command=run_python).pack()

# -- JavaScript (Simulated) --
js_tab = tk.Frame(lang_tabs, bg="#ffe")
lang_tabs.add(js_tab, text="JavaScript")

js_input = tk.Text(js_tab, height=10, font=("Consolas", 13))
js_input.pack(fill='x', padx=10, pady=5)

js_output = tk.Text(js_tab, height=10, font=("Consolas", 13), bg="#ffd")
js_output.pack(fill='both', expand=True, padx=10, pady=5)

def run_js_simulated():
    code = js_input.get("1.0", tk.END).strip()
    if "console.log(" in code:
        output = code.split("console.log(")[-1].split(")")[0]
        js_output.delete("1.0", tk.END)
        js_output.insert(tk.END, output)
    else:
        js_output.insert(tk.END, "Simulated: only console.log supported")

tk.Button(js_tab, text="Simulate JS", command=run_js_simulated).pack()

# -- HTML Preview --
html_tab = tk.Frame(lang_tabs, bg="#fdf")
lang_tabs.add(html_tab, text="HTML/JS")

html_input = tk.Text(html_tab, height=20, font=("Consolas", 13))
html_input.pack(fill='both', expand=True, padx=10, pady=5)

def preview_html():
    html_code = html_input.get("1.0", tk.END)
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
    tmp.write(html_code.encode("utf-8"))
    tmp.close()
    webbrowser.open(f"file://{tmp.name}")

tk.Button(html_tab, text="Preview HTML", command=preview_html).pack()

# ===== Run App =====
root.mainloop()
# This code creates a multi-functional application with a calculator, translator, notes, and code runner.