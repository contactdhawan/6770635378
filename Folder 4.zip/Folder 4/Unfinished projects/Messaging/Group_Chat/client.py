import socket
import threading
import tkinter as tk
from tkinter import simpledialog, scrolledtext
from datetime import datetime

HOST = '127.0.0.1'
PORT = 5001

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

# Ask for username
root = tk.Tk()
root.withdraw()
username = simpledialog.askstring("iMessage", "Enter your name:")
client.send(username.encode())
root.deiconify()

# Setup GUI like Apple Messages
root.title(f"{username}'s Chat")
root.geometry("520x520")
root.configure(bg="#f9f9f9")

chat_area = scrolledtext.ScrolledText(root, font=("Helvetica Neue", 12), bg="#ffffff", fg="#000000", state='disabled', wrap=tk.WORD)
chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

entry_frame = tk.Frame(root, bg="#f9f9f9")
entry_frame.pack(fill=tk.X, padx=10, pady=10)

entry = tk.Entry(entry_frame, font=("Helvetica Neue", 12))
entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10), ipady=6)

def insert_message(msg, local=False):
    chat_area.config(state='normal')
    align = 'right' if local else 'left'
    prefix = "" if local else "\n"
    tag = f"{align}_tag"
    chat_area.insert(tk.END, f"{prefix}{msg}\n", tag)
    chat_area.tag_config('left_tag', justify='left', lmargin1=10, foreground="#333333")
    chat_area.tag_config('right_tag', justify='right', rmargin=10, foreground="#1d88e5")
    chat_area.config(state='disabled')
    chat_area.yview(tk.END)

def send_msg():
    msg = entry.get().strip()
    if msg:
        full = f"{username}: {msg}"
        insert_message(f"[{datetime.now().strftime('%H:%M:%S')}] You: {msg}", local=True)
        client.send(full.encode())
        entry.delete(0, tk.END)

send_button = tk.Button(entry_frame, text="Send", command=send_msg, bg="#1d88e5", fg="white", font=("Helvetica Neue", 10, "bold"))
send_button.pack(side=tk.RIGHT)

def receive_msgs():
    while True:
        try:
            msg = client.recv(1024).decode()
            if msg:
                # Avoid displaying your own message if echoed back by server
                if not msg.startswith(f"{username}:"):
                    insert_message(msg, local=False)
            # Optionally, remove the above if your server doesn't echo back
        except:
            insert_message("[System] Disconnected from server.", local=False)
            break

entry.bind("<Return>", lambda e: send_msg())
threading.Thread(target=receive_msgs, daemon=True).start()
root.mainloop()
