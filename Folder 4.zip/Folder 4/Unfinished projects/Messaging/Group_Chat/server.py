import socket
import threading
from datetime import datetime

HOST = '127.0.0.1'
PORT = 5001

clients = []  # [(conn, username)]

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

def broadcast(msg, sender_conn=None):
    for conn, _ in clients:
        try:
            conn.send(msg.encode())
        except:
            conn.close()
            clients.remove((conn, _))

def handle_client(conn):
    try:
        username = conn.recv(1024).decode()
        clients.append((conn, username))
        welcome = f"[{datetime.now().strftime('%H:%M:%S')}] {username} joined the chat."
        broadcast(welcome)

        while True:
            msg = conn.recv(1024).decode()
            if msg:
                full_msg = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
                broadcast(full_msg)
    except:
        for c in clients:
            if c[0] == conn:
                leave_msg = f"[{datetime.now().strftime('%H:%M:%S')}] {c[1]} left the chat."
                broadcast(leave_msg)
                clients.remove(c)
                break
        conn.close()

def accept_clients():
    print("Server running...")
    while True:
        conn, _ = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()

accept_clients()
