# client.py

import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
import requests
import threading
import time
from datetime import datetime

# Your fixed server IP:
SERVER = "http://98.215.83.201:5000"
POLL_INTERVAL = 2  # seconds

EMOJI_MAP = {
    ":smile:": "😄",
    ":heart:": "❤️",
    ":thumbs_up:": "👍",
    ":laugh:": "😂",
    ":cry:": "😢",
    ":fire:": "🔥",
    ":star:": "⭐"
}

class ChatApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ani-Jai Messenger")
        self.geometry("520x640")
        self.resizable(False, False)

        self.user = None
        self.partner = None
        self.messages = []
        self.typing = False
        self.online_status = "..."

        self.style = ttk.Style(self)
        self.dark_mode = False

        self.login_screen()

    def login_screen(self):
        for widget in self.winfo_children():
            widget.destroy()

        ttk.Label(self, text="Select User", font=("Helvetica", 20)).pack(pady=50)

        frame = ttk.Frame(self)
        frame.pack()

        ttk.Button(frame, text="Login as Ani", command=lambda: self.login("Ani", "Jai")).grid(row=0, column=0, padx=20, ipadx=20, ipady=10)
        ttk.Button(frame, text="Login as Jai", command=lambda: self.login("Jai", "Ani")).grid(row=0, column=1, padx=20, ipadx=20, ipady=10)

    def login(self, user, partner):
        self.user = user
        self.partner = partner
        self.chat_screen()

    def chat_screen(self):
        for widget in self.winfo_children():
            widget.destroy()

        self.configure_style()

        top_frame = ttk.Frame(self)
        top_frame.pack(fill="x", pady=5)

        self.status_label = ttk.Label(top_frame, text=f"Talking to {self.partner} • {self.online_status}")
        self.status_label.pack(side="left", padx=10)

        ttk.Button(top_frame, text="☀️/🌙", command=self.toggle_theme).pack(side="right", padx=10)

        self.canvas = tk.Canvas(self, bg="#fff", highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)

        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        bottom_frame = ttk.Frame(self)
        bottom_frame.pack(fill="x", pady=10)

        self.entry = ttk.Entry(bottom_frame, font=("Helvetica", 12))
        self.entry.pack(side="left", fill="x", expand=True, padx=10)
        self.entry.bind("<Return>", lambda e: self.send_message())
        self.entry.bind("<Key>", lambda e: self.mark_typing())

        ttk.Button(bottom_frame, text="Send", command=self.send_message).pack(side="right", padx=5)

        self.refresh_messages()
        self.start_polling()

    def configure_style(self):
        bg = "#1e1e1e" if self.dark_mode else "#ffffff"
        fg = "#ffffff" if self.dark_mode else "#000000"
        self.style.theme_use("default")
        self.style.configure("TLabel", background=bg, foreground=fg)
        self.style.configure("TButton", background=bg, foreground=fg)
        self.configure(bg=bg)

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.chat_screen()

    def mark_typing(self):
        self.typing = True

    def send_message(self):
        msg = self.entry.get().strip()
        if not msg:
            return
        for key, emoji in EMOJI_MAP.items():
            msg = msg.replace(key, emoji)

        try:
            requests.post(f"{SERVER}/send", json={
                "sender": self.user,
                "receiver": self.partner,
                "message": msg
            })
            self.entry.delete(0, tk.END)
            self.refresh_messages()
        except:
            messagebox.showerror("Error", "Failed to send message")

    def refresh_messages(self):
        try:
            r = requests.get(f"{SERVER}/get", params={"user1": self.user, "user2": self.partner})
            messages = r.json()

            requests.post(f"{SERVER}/seen", json={"user": self.user, "partner": self.partner})

            if messages != self.messages:
                self.messages = messages
                self.display_messages()

            self.update_status()
        except:
            pass

    def display_messages(self):
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        for msg in self.messages:
            is_self = msg["sender"] == self.user
            frame = tk.Frame(self.scrollable_frame, bg="#DCF8C6" if is_self else "#F1F0F0", padx=10, pady=5)
            frame.pack(anchor="e" if is_self else "w", padx=10, pady=5, fill="x")

            txt = msg["message"]
            if msg["edited"]:
                txt += " (edited)"
            label = tk.Label(frame, text=txt, bg=frame["bg"], wraplength=320, justify="left", font=("Helvetica", 12))
            label.pack()

            meta = datetime.fromtimestamp(msg["timestamp"]).strftime("%H:%M")
            if is_self:
                if msg["seen"]:
                    meta += " • Seen"
            meta_label = tk.Label(frame, text=meta, bg=frame["bg"], font=("Helvetica", 8), fg="#555")
            meta_label.pack(anchor="e")

            if is_self:
                frame.bind("<Button-3>", lambda e, m=msg: self.message_menu(m))

        self.canvas.update_idletasks()
        self.canvas.yview_moveto(1)

    def message_menu(self, msg):
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Edit", command=lambda: self.edit_message(msg))
        menu.add_command(label="Delete", command=lambda: self.delete_message(msg["id"]))
        menu.post(self.winfo_pointerx(), self.winfo_pointery())

    def edit_message(self, msg):
        new = simpledialog.askstring("Edit Message", "Edit your message:", initialvalue=msg["message"])
        if new is None:
            return
        for key, emoji in EMOJI_MAP.items():
            new = new.replace(key, emoji)
        requests.post(f"{SERVER}/edit", json={"id": msg["id"], "new_message": new})
        self.refresh_messages()

    def delete_message(self, msg_id):
        if messagebox.askyesno("Delete Message", "Are you sure you want to delete this message?"):
            requests.post(f"{SERVER}/delete", json={"id": msg_id})
            self.refresh_messages()

    def update_status(self):
        try:
            r = requests.get(f"{SERVER}/status/{self.partner}")
            status = r.json()["status"]
            dot = "🟢" if status == "online" else "⚪️"
            self.status_label.config(text=f"Talking to {self.partner} • {dot} {status}")
        except:
            self.status_label.config(text=f"Talking to {self.partner} • ...")

    def start_polling(self):
        def poll():
            while True:
                time.sleep(POLL_INTERVAL)
                self.refresh_messages()

        threading.Thread(target=poll, daemon=True).start()

if __name__ == "__main__":
    app = ChatApp()
    app.mainloop()
