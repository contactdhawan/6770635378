# server.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import time

app = Flask(__name__)
CORS(app)

DB_FILE = "chat.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender TEXT NOT NULL,
        receiver TEXT NOT NULL,
        message TEXT NOT NULL,
        timestamp REAL,
        edited INTEGER DEFAULT 0,
        seen INTEGER DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        name TEXT PRIMARY KEY,
        last_active REAL
    )''')

    conn.commit()
    conn.close()

@app.route("/send", methods=["POST"])
def send():
    data = request.json
    sender = data["sender"]
    receiver = data["receiver"]
    message = data["message"]
    timestamp = time.time()

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO messages (sender, receiver, message, timestamp) VALUES (?, ?, ?, ?)",
              (sender, receiver, message, timestamp))
    c.execute("INSERT OR REPLACE INTO users (name, last_active) VALUES (?, ?)", (sender, timestamp))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/get", methods=["GET"])
def get():
    user1 = request.args.get("user1")
    user2 = request.args.get("user2")

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT * FROM messages WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?) ORDER BY timestamp ASC",
              (user1, user2, user2, user1))
    rows = c.fetchall()

    c.execute("INSERT OR REPLACE INTO users (name, last_active) VALUES (?, ?)", (user1, time.time()))
    conn.commit()
    conn.close()

    return jsonify([
        {
            "id": row[0],
            "sender": row[1],
            "receiver": row[2],
            "message": row[3],
            "timestamp": row[4],
            "edited": row[5],
            "seen": row[6]
        } for row in rows
    ])

@app.route("/seen", methods=["POST"])
def mark_seen():
    data = request.json
    user = data["user"]
    partner = data["partner"]

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE messages SET seen = 1 WHERE receiver=? AND sender=?", (user, partner))
    c.execute("INSERT OR REPLACE INTO users (name, last_active) VALUES (?, ?)", (user, time.time()))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/edit", methods=["POST"])
def edit():
    data = request.json
    msg_id = data["id"]
    new_msg = data["new_message"]

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE messages SET message=?, edited=1 WHERE id=?", (new_msg, msg_id))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/delete", methods=["POST"])
def delete():
    data = request.json
    msg_id = data["id"]

    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM messages WHERE id=?", (msg_id,))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/status/<user>", methods=["GET"])
def status(user):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT last_active FROM users WHERE name=?", (user,))
    row = c.fetchone()
    conn.close()

    if not row:
        return jsonify({"status": "offline"})

    last_active = row[0]
    now = time.time()
    diff = now - last_active
    if diff < 60:
        return jsonify({"status": "online"})
    else:
        return jsonify({"status": f"Last seen {int(diff // 60)} min(s) ago"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)
