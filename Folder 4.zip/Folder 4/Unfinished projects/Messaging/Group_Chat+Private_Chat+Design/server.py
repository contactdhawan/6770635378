import socket
import threading
from datetime import datetime

HOST = '127.0.0.1'
PORT = 6000

clients = {}  # conn: username

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

def broadcast_userlist():
    users = list(clients.values())
    msg = "__userlist__:" + ",".join(users)
    for conn in clients:
        try:
            conn.send(msg.encode())
        except:
            pass

def send_message_to(target_username, message):
    for conn, username in clients.items():
        if username == target_username:
            try:
                conn.send(message.encode())
            except:
                pass
            break

def handle_client(conn):
    try:
        username = conn.recv(1024).decode()
        clients[conn] = username
        print(f"{username} connected.")
        broadcast_userlist()
        broadcast_all(f"[{timestamp()}] System: {username} joined the chat.")

        while True:
            data = conn.recv(2048).decode()
            if not data:
                break

            # Message format:
            # group:<message>     or
            # private:<target_username>:<message>

            if data.startswith("group:"):
                content = data[len("group:"):]
                broadcast_all(f"[{timestamp()}] {username}: {content}")

            elif data.startswith("private:"):
                _, target, content = data.split(":", 2)
                send_message_to(target, f"[{timestamp()}] {username} (private): {content}")

    except Exception as e:
        print("Client error:", e)
    finally:
        if conn in clients:
            left_user = clients[conn]
            print(f"{left_user} disconnected.")
            del clients[conn]
            broadcast_userlist()
            broadcast_all(f"[{timestamp()}] System: {left_user} left the chat.")
            conn.close()

def broadcast_all(message):
    for conn in list(clients.keys()):
        try:
            conn.send(message.encode())
        except:
            conn.close()
            if conn in clients:
                del clients[conn]

def timestamp():
    return datetime.now().strftime("%H:%M:%S")

def accept_clients():
    print(f"Server started on {HOST}:{PORT}")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()

accept_clients()
