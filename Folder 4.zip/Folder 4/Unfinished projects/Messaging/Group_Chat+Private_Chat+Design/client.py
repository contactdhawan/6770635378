import socket
import threading
import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext
from datetime import datetime
import re

HOST = '127.0.0.1'
PORT = 6000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

# Ask username on launch
root = tk.Tk()
root.withdraw()
username = simpledialog.askstring("Username", "Enter your username:")
if not username:
    exit()
client.send(username.encode())
root.deiconify()

root.title(f"Chat - {username}")
root.geometry("800x500")
root.minsize(700, 450)

# === Themes ===
LIGHT_BG = "#f0f0f0"
LIGHT_CHAT_BG = "#ffffff"
LIGHT_TEXT = "#000000"
LIGHT_SIDEBAR_BG = "#d9d9d9"
LIGHT_BUBBLE_USER = "#dcf8c6"
LIGHT_BUBBLE_OTHER = "#ffffff"

DARK_BG = "#1e1e1e"
DARK_CHAT_BG = "#2c2c2c"
DARK_TEXT = "#e0e0e0"
DARK_SIDEBAR_BG = "#333333"
DARK_BUBBLE_USER = "#056162"
DARK_BUBBLE_OTHER = "#262626"

is_dark_mode = False

# === UI Setup ===
root.configure(bg=LIGHT_BG)

# Sidebar Frame for users
sidebar_frame = tk.Frame(root, width=180, bg=LIGHT_SIDEBAR_BG)
sidebar_frame.pack(side=tk.LEFT, fill=tk.Y)

sidebar_label = tk.Label(sidebar_frame, text="Chats", bg=LIGHT_SIDEBAR_BG, fg=LIGHT_TEXT, font=("Helvetica", 14, "bold"))
sidebar_label.pack(pady=10)

# Listbox of users + group
user_listbox = tk.Listbox(sidebar_frame, font=("Helvetica", 12))
user_listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
user_listbox.insert(tk.END, "Group Chat")
user_listbox.select_set(0)

# Chat frame
chat_frame = tk.Frame(root, bg=LIGHT_BG)
chat_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Chat display
chat_display = scrolledtext.ScrolledText(chat_frame, font=("Helvetica", 12), bg=LIGHT_CHAT_BG, fg=LIGHT_TEXT, state="disabled", wrap=tk.WORD)
chat_display.pack(padx=10, pady=(10, 0), fill=tk.BOTH, expand=True)

# Input frame
input_frame = tk.Frame(chat_frame, bg=LIGHT_BG)
input_frame.pack(fill=tk.X, padx=10, pady=10)

message_var = tk.StringVar()
message_entry = tk.Entry(input_frame, textvariable=message_var, font=("Helvetica", 12))
message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6, padx=(0, 10))

send_button = tk.Button(input_frame, text="Send", font=("Helvetica", 11, "bold"), width=10, bg="#4caf50", fg="white")
send_button.pack(side=tk.LEFT)

# Toggle Dark Mode button
def toggle_theme():
    global is_dark_mode
    is_dark_mode = not is_dark_mode
    apply_theme()

theme_button = tk.Button(sidebar_frame, text="Toggle Dark Mode", command=toggle_theme, bg="#888", fg="white")
theme_button.pack(pady=10)

# === Chat Data ===
# Store messages per user/group
chat_history = {"Group Chat": []}
current_chat = "Group Chat"

def timestamp():
    return datetime.now().strftime("%H:%M:%S")

def apply_theme():
    if is_dark_mode:
        bg = DARK_BG
        chat_bg = DARK_CHAT_BG
        text_color = DARK_TEXT
        sidebar_bg = DARK_SIDEBAR_BG
        bubble_user = DARK_BUBBLE_USER
        bubble_other = DARK_BUBBLE_OTHER
    else:
        bg = LIGHT_BG
        chat_bg = LIGHT_CHAT_BG
        text_color = LIGHT_TEXT
        sidebar_bg = LIGHT_SIDEBAR_BG
        bubble_user = LIGHT_BUBBLE_USER
        bubble_other = LIGHT_BUBBLE_OTHER

    root.configure(bg=bg)
    sidebar_frame.configure(bg=sidebar_bg)
    sidebar_label.configure(bg=sidebar_bg, fg=text_color)
    user_listbox.configure(bg=sidebar_bg, fg=text_color, selectbackground="#4caf50" if not is_dark_mode else "#056162", selectforeground="white")
    chat_frame.configure(bg=bg)
    chat_display.configure(bg=chat_bg, fg=text_color)
    input_frame.configure(bg=bg)
    message_entry.configure(bg="white" if not is_dark_mode else "#555555", fg=text_color, insertbackground=text_color)
    send_button.configure(bg="#4caf50", fg="white")
    theme_button.configure(bg="#555" if is_dark_mode else "#888")

    # Refresh chat display colors
    display_chat(current_chat)

def display_chat(chat_name):
    chat_display.config(state="normal")
    chat_display.delete("1.0", tk.END)
    msgs = chat_history.get(chat_name, [])
    for sender, text, ts in msgs:
        align = "right" if sender == username else "left"
        prefix = f"[{ts}] You: " if sender == username else f"[{ts}] {sender}: "
        chat_display.insert(tk.END, prefix + text + "\n")
    chat_display.config(state="disabled")
    chat_display.yview(tk.END)

def send_message():
    global current_chat
    msg = message_var.get().strip()
    if not msg:
        return
    ts = timestamp()
    chat_history.setdefault(current_chat, []).append((username, msg, ts))
    display_chat(current_chat)
    message_var.set("")
    # Send to server with protocol:
    if current_chat == "Group Chat":
        to_send = f"group:{msg}"
    else:
        to_send = f"private:{current_chat}:{msg}"
    try:
        client.send(to_send.encode())
    except:
        messagebox.showerror("Connection Error", "Failed to send message.")

send_button.config(command=send_message)
message_entry.bind("<Return>", lambda e: send_message())

def receive_messages():
    while True:
        try:
            data = client.recv(4096).decode()
            if not data:
                break

            if data.startswith("__userlist__:"):
                users = data[len("__userlist__:"):].split(",")
                users = [u for u in users if u != username]
                # Update sidebar but keep group chat first
                existing = set(user_listbox.get(0, tk.END))
                # Add new users to chat_history if needed
                for u in users:
                    if u not in chat_history:
                        chat_history[u] = []
                # Remove users who left
                for user_in_list in existing:
                    if user_in_list != "Group Chat" and user_in_list not in users:
                        if user_in_list in chat_history:
                            del chat_history[user_in_list]
                # Refresh Listbox
                user_listbox.delete(1, tk.END)
                for u in users:
                    user_listbox.insert(tk.END, u)
                # Keep current chat selected if still there, else group
                if current_chat not in chat_history:
                    switch_chat("Group Chat")

            else:
                m = re.match(r"\[(\d{2}:\d{2}:\d{2})\] (.+?)( \(private\))?: (.*)", data)
                if m:
                    ts, sender, private, message = m.groups()
                    private = private is not None

                    # Ignore echoed messages from ourselves:
                    if sender == username:
                        continue

                    chat_key = "Group Chat" if not private else sender
                    if chat_key not in chat_history:
                        chat_history[chat_key] = []

                    chat_history[chat_key].append((sender, message, ts))

                    if chat_key == current_chat:
                        display_chat(current_chat)

        except:
            break

def switch_chat(chat_name):
    global current_chat
    current_chat = chat_name
    display_chat(current_chat)

user_listbox.bind("<<ListboxSelect>>", lambda e: switch_chat(user_listbox.get(user_listbox.curselection())))

apply_theme()

threading.Thread(target=receive_messages, daemon=True).start()

root.mainloop()
