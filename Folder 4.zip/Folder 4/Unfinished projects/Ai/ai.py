import openai
import sqlite3
import nltk
from nltk.tokenize import word_tokenize
from transformers import pipeline
import os

# Download necessary NLP resources
nltk.download('punkt')

# Set up OpenAI API Key from environment variable
openai.api_key = os.getenv("OPENAI_API_KEY")
if not openai.api_key:
    raise ValueError("OPENAI_API_KEY")

# Connect to a local database (for storing useful data)
conn = sqlite3.connect('chatbot.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS info (
                    id INTEGER PRIMARY KEY,
                    topic TEXT,
                    details TEXT)''')
conn.commit()

# Sentiment Analysis Model (helps chatbot adjust tone)
sentiment_pipeline = pipeline("sentiment-analysis")

def get_ai_response(user_input):
    """Use GPT to generate human-like responses."""
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": user_input}]
    )
    return response["choices"][0]["message"]["content"]

def analyze_sentiment(text):
    """Detect user emotion to tailor chatbot's responses."""
    sentiment = sentiment_pipeline(text)[0]
    return sentiment["label"]

def get_database_info(topic):
    """Fetch helpful information stored in the database."""
    cursor.execute("SELECT details FROM info WHERE topic=?", (topic,))
    result = cursor.fetchone()
    return result[0] if result else None

def chatbot(user_input):
    """Core chatbot logic combining database, AI responses, and sentiment."""
    words = word_tokenize(user_input.lower())
    sentiment = analyze_sentiment(user_input)

    # Check database for relevant info
    for word in words:
        info = get_database_info(word)
        if info:
            return f"Here's some info on {word}: {info}"

    # If no database match, use AI
    ai_response = get_ai_response(user_input)

    # Adjust response based on sentiment
    if sentiment == "NEGATIVE":
        return f"I'm sorry you're feeling this way. Here's something to help: {ai_response}"
    else:
        return ai_response

# Interactive chat loop
print("Chatbot: Hello! Type 'exit' to end the chat.")
while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        print("Chatbot: Goodbye!")
        break
    print("Chatbot:", chatbot(user_input))

conn.close()