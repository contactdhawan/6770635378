from PIL import Image
import ctypes
import os

def is_valid_image(path):
    try:
        with Image.open(path) as img:
            img.verify()
        return True
    except Exception:
        return False

def Wallpaper():
    image_path = os.path.abspath("wallpaper.jpg")  # Image must exist

    if not os.path.exists(image_path):
        print("Wallpaper image not found.")
        return

    if not is_valid_image(image_path):
        print("Invalid image file.")
        return

    # Set as desktop wallpaper (Windows only)
    ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 3)
    print("Wallpaper changed.")
