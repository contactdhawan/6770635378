import tkinter as tk
from PIL import Image, ImageTk
import pyautogui
import threading
import time
import ctypes

# Optional: hide system cursor completely in Windows
ctypes.windll.user32.ShowCursor(False)

# Create transparent fullscreen always-on-top window
root = tk.Tk()
root.attributes("-topmost", True)
root.attributes("-transparentcolor", "black")  # Makes black fully transparent
root.overrideredirect(True)  # Removes window border
root.configure(bg="black")

# Load and resize cursor images (32x32 pixels)

# Load and resize cursor images (32x32 pixels)
idle_img_pil = Image.open("cursor_idle.png").resize((32, 32), Image.Resampling.LANCZOS)
click_img_pil = Image.open("cursor_click.png").resize((32, 32), Image.Resampling.LANCZOS)
idle_img = ImageTk.PhotoImage(idle_img_pil)
click_img = ImageTk.PhotoImage(click_img_pil)

# Set screen size
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
root.geometry(f"{screen_width}x{screen_height}+0+0")

# Label for displaying cursor
cursor_label = tk.Label(root, image=idle_img, bg="black", bd=0)
cursor_label.place(x=0, y=0)

# Track click state
is_pressed = False

# Function to update cursor position and state
def update_cursor():
    global is_pressed
    while True:
        x, y = pyautogui.position()
        cursor_label.place(x=x, y=y)
        if pyautogui.mouseDown():
            if not is_pressed:
                cursor_label.config(image=click_img)
                is_pressed = True
        else:
            if is_pressed:
                cursor_label.config(image=idle_img)
                is_pressed = False
        time.sleep(0.01)  # 10ms delay

# Start the updater in a separate thread
threading.Thread(target=update_cursor, daemon=True).start()

# Start the main window
root.mainloop()