import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import subprocess
import threading
import keyword
import re
import json

class CodeVerse(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CodeVerse IDE")
        self.geometry("1300x800")
        self.configure(bg="#1e1e1e")
        self.tabs = {}
        self.settings = self.load_settings()
        self._build_ui()

    def _build_ui(self):
        self._init_styles()
        self._create_menu()
        self._create_sidebar()
        self._create_notebook()
        self._create_statusbar()
        self._create_searchbar()
        self._create_command_palette()
        self._create_theme_switcher()
        self.new_file()

    def load_settings(self):
        try:
            with open("settings.json", "r") as f:
                return json.load(f)
        except:
            return {"theme": "dark"}

    def save_settings(self):
        with open("settings.json", "w") as f:
            json.dump(self.settings, f, indent=4)

    def _create_theme_switcher(self):
        self.theme_menu = tk.Menu(self, tearoff=0)
        self.theme_menu.add_command(label="Dark Theme", command=lambda: self.apply_theme("dark"))
        self.theme_menu.add_command(label="Light Theme", command=lambda: self.apply_theme("light"))

    def apply_theme(self, theme):
        if theme == "dark":
            self.configure(bg="#1e1e1e")
        elif theme == "light":
            self.configure(bg="#ffffff")
        self.settings["theme"] = theme
        self.save_settings()

    def _init_styles(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure("TNotebook", background="#2d2d2d")
        style.configure("TNotebook.Tab", background="#444", foreground="white", padding=[10, 5])
        style.map("TNotebook.Tab", background=[("selected", "#007acc")])
        style.configure("Treeview", background="#252526", fieldbackground="#252526", foreground="white")
        style.configure("TLabel", background="#1e1e1e", foreground="white")
        style.configure("TEntry", fieldbackground="#2d2d2d", foreground="white")

    def _create_menu(self):
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="New File", command=self.new_file)
        filemenu.add_command(label="Open File", command=self.open_file)
        filemenu.add_command(label="Save", command=self.save_file)
        filemenu.add_command(label="Save As", command=self.save_file_as)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=filemenu)

        runmenu = tk.Menu(menubar, tearoff=0)
        runmenu.add_command(label="Run", command=self.run_code)
        menubar.add_cascade(label="Run", menu=runmenu)

        searchmenu = tk.Menu(menubar, tearoff=0)
        searchmenu.add_command(label="Find & Replace", command=self.toggle_searchbar)
        menubar.add_cascade(label="Search", menu=searchmenu)

        thememenu = tk.Menu(menubar, tearoff=0)
        thememenu.add_command(label="Switch Theme", command=self.toggle_theme_menu)
        menubar.add_cascade(label="Appearance", menu=thememenu)

        commandmenu = tk.Menu(menubar, tearoff=0)
        commandmenu.add_command(label="Command Palette", command=self.toggle_command_palette)
        menubar.add_cascade(label="Tools", menu=commandmenu)

        self.config(menu=menubar)

    def toggle_theme_menu(self):
        try:
            self.theme_menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            self.theme_menu.grab_release()

    def _create_notebook(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

    def _create_statusbar(self):
        self.status = tk.StringVar()
        self.status.set("Ready")
        statusbar = ttk.Label(self, textvariable=self.status, anchor="w")
        statusbar.pack(side="bottom", fill="x")

    def _create_searchbar(self):
        self.search_frame = ttk.Frame(self)
        self.search_entry = ttk.Entry(self.search_frame)
        self.replace_entry = ttk.Entry(self.search_frame)
        self.search_btn = ttk.Button(self.search_frame, text="Find", command=self.find_text)
        self.replace_btn = ttk.Button(self.search_frame, text="Replace", command=self.replace_text)
        self.search_entry.pack(side="left", padx=5)
        self.replace_entry.pack(side="left", padx=5)
        self.search_btn.pack(side="left", padx=5)
        self.replace_btn.pack(side="left", padx=5)
        self.search_frame.pack_forget()

    def toggle_searchbar(self):
        if self.search_frame.winfo_ismapped():
            self.search_frame.pack_forget()
        else:
            self.search_frame.pack(side="top", fill="x")

    def find_text(self):
        tab = self.get_current_tab()
        if not tab: return
        text = tab["text"]
        target = self.search_entry.get()
        text.tag_remove("highlight", "1.0", tk.END)
        if target:
            start = "1.0"
            while True:
                pos = text.search(target, start, stopindex=tk.END)
                if not pos:
                    break
                end = f"{pos}+{len(target)}c"
                text.tag_add("highlight", pos, end)
                text.tag_config("highlight", background="yellow", foreground="black")
                start = end

    def replace_text(self):
        tab = self.get_current_tab()
        if not tab: return
        content = tab["text"].get("1.0", tk.END)
        content = content.replace(self.search_entry.get(), self.replace_entry.get())
        tab["text"].delete("1.0", tk.END)
        tab["text"].insert("1.0", content)

    def _create_command_palette(self):
        self.command_palette = tk.Toplevel(self)
        self.command_palette.withdraw()
        self.command_palette.overrideredirect(True)
        self.command_palette.geometry("400x100+400+300")
        self.command_entry = ttk.Entry(self.command_palette, font=("Segoe UI", 14))
        self.command_entry.pack(fill="both", expand=True)
        self.command_entry.bind("<Return>", self.execute_command)
        self.command_entry.focus()

    def toggle_command_palette(self):
        if self.command_palette.winfo_ismapped():
            self.command_palette.withdraw()
        else:
            self.command_palette.deiconify()
            self.command_entry.delete(0, tk.END)
            self.command_entry.focus()

    def execute_command(self, event=None):
        cmd = self.command_entry.get().lower()
        if cmd == "new file": self.new_file()
        elif cmd == "save": self.save_file()
        elif cmd == "run": self.run_code()
        elif cmd == "find": self.toggle_searchbar()
        else: self.status.set(f"Unknown command: {cmd}")
        self.command_palette.withdraw()

    def _create_sidebar(self):
        # Placeholder: real file tree browser coming soon
        pass

    def new_file(self):
        frame = ttk.Frame(self.notebook)
        text = tk.Text(frame, wrap="none", bg="#1e1e1e", fg="#ffffff", insertbackground="white", font=("Consolas", 12))
        text.pack(fill="both", expand=True)
        tab_id = self.notebook.add(frame, text="Untitled")
        self.tabs[tab_id] = {"text": text, "file": None}
        self.notebook.select(tab_id)

    def get_current_tab(self):
        tab_id = self.notebook.select()
        return self.tabs.get(tab_id, None)

    def open_file(self):
        filepath = filedialog.askopenfilename()
        if filepath:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
            frame = ttk.Frame(self.notebook)
            text = tk.Text(frame, wrap="none", bg="#1e1e1e", fg="#ffffff", insertbackground="white", font=("Consolas", 12))
            text.insert("1.0", content)
            text.pack(fill="both", expand=True)
            filename = os.path.basename(filepath)
            tab_id = self.notebook.add(frame, text=filename)
            self.tabs[tab_id] = {"text": text, "file": filepath}
            self.notebook.select(tab_id)

    def save_file(self):
        tab = self.get_current_tab()
        if tab:
            filepath = tab["file"]
            if filepath:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(tab["text"].get("1.0", tk.END))
                self._update_tab_title(filepath)
            else:
                self.save_file_as()

    def save_file_as(self):
        tab = self.get_current_tab()
        if tab:
            filepath = filedialog.asksaveasfilename(defaultextension=".txt")
            if filepath:
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(tab["text"].get("1.0", tk.END))
                tab["file"] = filepath
                self._update_tab_title(filepath)

    def _update_tab_title(self, filepath):
        filename = os.path.basename(filepath)
        tab_id = self.notebook.select()
        self.notebook.tab(tab_id, text=filename)

    def run_code(self):
        tab = self.get_current_tab()
        if tab:
            code = tab["text"].get("1.0", tk.END)
            def execute():
                result = subprocess.run(["python", "-c", code], capture_output=True, text=True)
                messagebox.showinfo("Output", result.stdout if result.stdout else result.stderr)
            threading.Thread(target=execute).start()

if __name__ == "__main__":
    app = CodeVerse()
    app.mainloop()
