# print('Give me a number bigger that 9')
# number = input()
# number = float(number)
# if number>9:
#     print("Your number is more than 9!")
# else:
#     print("You failed")


      
