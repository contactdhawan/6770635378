import random
import turtle as t

t.bgcolor('yellow')
t.tracer(0)  # Turn off automatic animation for smoothness

# Player 1 Caterpillar (Red)
caterpillar1 = t.Turtle()
caterpillar1.shape('square')
caterpillar1.color('red')
caterpillar1.penup()
caterpillar1.hideturtle()
caterpillar1.speed(0)
caterpillar1.shapesize(1, 3, 1)

# Player 2 Caterpillar (Green)
caterpillar2 = t.Turtle()
caterpillar2.shape('square')
caterpillar2.color('green')
caterpillar2.penup()
caterpillar2.hideturtle()
caterpillar2.speed(0)
caterpillar2.shapesize(1, 3, 1)

leaf = t.Turtle()
leaf_shape = ((0, 0), (14, 2), (18, 6), (20, 20), (6, 18), (2, 14))
t.register_shape('leaf', leaf_shape)
leaf.shape('leaf')
leaf.color('green')
leaf.penup()
leaf.hideturtle()
leaf.speed(0)

game_started = False
score = 0
caterpillar_speed = 2
caterpillar_length = 3
directions = [0, 180]  # Player 1: right, Player 2: left

text_turtle = t.Turtle()
text_turtle.write('Press "space" to start the game', align='center', font=('Arial', 16, 'bold'))
text_turtle.hideturtle()

score_turtle = t.Turtle()
score_turtle.hideturtle()
score_turtle.speed(0)

game_over_turtle = t.Turtle()
game_over_turtle.hideturtle()

def outside_window(caterpillar):
    left_wall = -t.window_width() / 2
    right_wall = t.window_width() / 2
    top_wall = t.window_height() / 2
    bottom_wall = -t.window_height() / 2
    (x, y) = caterpillar.pos()
    return x < left_wall or x > right_wall or y < bottom_wall or y > top_wall

def game_over():
    caterpillar1.color('yellow')
    caterpillar2.color('yellow')
    leaf.color('yellow')
    game_over_turtle.clear()
    game_over_turtle.penup()
    game_over_turtle.hideturtle()
    game_over_turtle.write('GAME OVER! Press "R" to restart', align='center', font=('Arial', 30, 'normal'))
    t.update()

def reset_game():
    global game_started, score, caterpillar_speed, caterpillar_length, directions
    game_started = False
    score = 0
    caterpillar_speed = 2
    caterpillar_length = 3
    directions = [0, 180]
    caterpillar1.color('red')
    caterpillar2.color('green')
    caterpillar1.setpos(-50, 0)
    caterpillar2.setpos(50, 0)
    caterpillar1.setheading(0)
    caterpillar2.setheading(180)
    caterpillar1.shapesize(1, 3, 1)
    caterpillar2.shapesize(1, 3, 1)
    caterpillar1.hideturtle()
    caterpillar2.hideturtle()
    text_turtle.clear()
    score_turtle.clear()
    game_over_turtle.clear()
    text_turtle.write('Press "space" to start the game', align='center', font=('Arial', 16, 'bold'))
    place_leaf()
    t.update()

def display_score(current_score):
    score_turtle.clear()
    score_turtle.penup()
    x = (t.window_width() / 2) - 50
    y = (t.window_height() / 2) - 50
    score_turtle.setpos(x, y)
    score_turtle.write(str(current_score), align='right', font=('Arial', 40, 'bold'))

def place_leaf():
    leaf.color('green')
    leaf.ht()
    max_x = (t.window_width() // 2) - 40
    max_y = (t.window_height() // 2) - 40
    leaf.setx(random.randint(-max_x, max_x))
    leaf.sety(random.randint(-max_y, max_y))
    leaf.st()

def start_game():
    global game_started, score, caterpillar_speed, caterpillar_length
    if game_started:
        return
    game_started = True
    score = 0
    caterpillar_speed = 2
    caterpillar_length = 3
    text_turtle.clear()
    game_over_turtle.clear()
    display_score(score)
    place_leaf()
    caterpillar1.setpos(-50, 0)
    caterpillar2.setpos(50, 0)
    caterpillar1.setheading(0)
    caterpillar2.setheading(180)
    caterpillar1.shapesize(1, caterpillar_length, 1)
    caterpillar2.shapesize(1, caterpillar_length, 1)
    caterpillar1.showturtle()
    caterpillar2.showturtle()
    move_game()

def move_game():
    global score, caterpillar_speed, caterpillar_length
    if not game_started:
        return
    caterpillar1.setheading(directions[0])
    caterpillar2.setheading(directions[1])
    caterpillar1.forward(caterpillar_speed)
    caterpillar2.forward(caterpillar_speed)
    if caterpillar1.distance(leaf) < 70 or caterpillar2.distance(leaf) < 70:
        place_leaf()
        caterpillar_length += 1
        caterpillar1.shapesize(1, caterpillar_length, 1)
        caterpillar2.shapesize(1, caterpillar_length, 1)
        caterpillar_speed += 1
        score += 100
        display_score(score)
    if outside_window(caterpillar1) or outside_window(caterpillar2):
        game_over()
        return
    t.update()
    t.ontimer(move_game, 5)

# Player 1 (Arrow keys)
def move1_up():
    if directions[0] == 0 or directions[0] == 180:
        directions[0] = 90
def move1_down():
    if directions[0] == 0 or directions[0] == 180:
        directions[0] = 270
def move1_left():
    if directions[0] == 90 or directions[0] == 270:
        directions[0] = 180
def move1_right():
    if directions[0] == 90 or directions[0] == 270:
        directions[0] = 0

# Player 2 (WASD)
def move2_up():
    if directions[1] == 0 or directions[1] == 180:
        directions[1] = 90
def move2_down():
    if directions[1] == 0 or directions[1] == 180:
        directions[1] = 270
def move2_left():
    if directions[1] == 90 or directions[1] == 270:
        directions[1] = 180
def move2_right():
    if directions[1] == 90 or directions[1] == 270:
        directions[1] = 0

t.onkey(start_game, 'space')
# Player 1 controls (Arrow keys)
t.onkey(move1_up, 'Up')
t.onkey(move1_down, 'Down')
t.onkey(move1_left, 'Left')
t.onkey(move1_right, 'Right')
# Player 2 controls (WASD)
t.onkey(move2_up, 'w')
t.onkey(move2_down, 's')
t.onkey(move2_left, 'a')
t.onkey(move2_right, 'd')
t.onkey(reset_game, 'r')
t.listen()
t.mainloop()