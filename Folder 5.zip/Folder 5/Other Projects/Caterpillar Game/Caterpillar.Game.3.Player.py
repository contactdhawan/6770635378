import random
import turtle as t

t.bgcolor('yellow')
t.tracer(0)  # Turn off automatic animation for smoothness

# --- Create three caterpillars, one for each player ---
caterpillars = []
colors = ['red', 'blue', 'purple']
start_positions = [(0, 0), (-50, 50), (50, -50)]
for i in range(3):
    c = t.Turtle()
    c.shape('square')
    c.color(colors[i])
    c.penup()
    c.hideturtle()
    c.speed(0)
    c.shapesize(1, 3, 1)
    c.setpos(start_positions[i])
    caterpillars.append(c)

# --- Create the leaf (food) ---
leaf = t.Turtle()
leaf_shape = ((0, 0), (14, 2), (18, 6), (20, 20), (6, 18), (2, 14))
t.register_shape('leaf', leaf_shape)
leaf.shape('leaf')
leaf.color('green')
leaf.penup()
leaf.hideturtle()
leaf.speed(0)

# --- Game state variables ---
game_started = False
score = 0
caterpillar_length = 3
caterpillar_speed = 2

# --- Text turtles for messages and score ---
text_turtle = t.Turtle()
text_turtle.write('Press "space" to start the game', align='center', font=('Arial', 16, 'bold'))
text_turtle.hideturtle()

score_turtle = t.Turtle()
score_turtle.hideturtle()
score_turtle.speed(0)

game_over_turtle = t.Turtle()
game_over_turtle.hideturtle()

# --- Hack status display turtle ---
hack_status_turtle = t.Turtle()
hack_status_turtle.hideturtle()
hack_status_turtle.penup()
hack_status_turtle.speed(0)

# --- Store each caterpillar's direction ---
# 0=right, 90=up, 180=left, 270=down
directions = [0, 0, 0]

# --- Hack flags and cooldowns for each player ---
hack_flags = [False, False, False]
hack_cooldowns = [False, False, False]

# --- Hack key handlers with cooldown ---
def hack_on1():
    if not hack_cooldowns[0]:
        hack_flags[0] = True
        hack_cooldowns[0] = True
        display_hack_status()
        t.ontimer(lambda: end_hack(0), 5000)
def hack_off1():
    hack_flags[0] = False
    display_hack_status()

def hack_on2():
    if not hack_cooldowns[1]:
        hack_flags[1] = True
        hack_cooldowns[1] = True
        display_hack_status()
        t.ontimer(lambda: end_hack(1), 5000)
def hack_off2():
    hack_flags[1] = False
    display_hack_status()

def hack_on3():
    if not hack_cooldowns[2]:
        hack_flags[2] = True
        hack_cooldowns[2] = True
        display_hack_status()
        t.ontimer(lambda: end_hack(2), 5000)
def hack_off3():
    hack_flags[2] = False
    display_hack_status()

def end_hack(player_idx):
    hack_flags[player_idx] = False
    hack_cooldowns[player_idx] = False
    display_hack_status()

def display_hack_status():
    hack_status_turtle.clear()
    y = (t.window_height() / 2) - 30
    for i, flag in enumerate(hack_flags):
        msg = f"P{i+1} HACK: {'ON' if flag else ('COOLDOWN' if hack_cooldowns[i] else 'OFF')}"
        hack_status_turtle.penup()
        hack_status_turtle.setpos(-t.window_width() / 2 + 10, y - i * 30)
        hack_status_turtle.pendown()
        hack_status_turtle.write(msg, align='left', font=('Arial', 14, 'bold'))

def outside_window(cat):
    left_wall = -t.window_width() / 2
    right_wall = t.window_width() / 2
    top_wall = t.window_height() / 2
    bottom_wall = -t.window_height() / 2
    (x, y) = cat.pos()
    return x < left_wall or x > right_wall or y < bottom_wall or y > top_wall

def game_over():
    for cat in caterpillars:
        cat.color('yellow')
    leaf.color('yellow')
    game_over_turtle.clear()
    game_over_turtle.penup()
    game_over_turtle.hideturtle()
    game_over_turtle.write('GAME OVER! Press "R" to restart', align='center', font=('Arial', 30, 'normal'))
    t.update()

def reset_game():
    global game_started, caterpillar_length, caterpillar_speed, directions, score
    game_started = False
    caterpillar_length = 3
    caterpillar_speed = 2
    score = 0
    directions = [0, 0, 0]
    for i, cat in enumerate(caterpillars):
        cat.color(colors[i])
        cat.setpos(start_positions[i])
        cat.setheading(0)
        cat.shapesize(1, 3, 1)
        cat.hideturtle()
    text_turtle.clear()
    score_turtle.clear()
    game_over_turtle.clear()
    hack_status_turtle.clear()
    text_turtle.write('Press "space" to start the game', align='center', font=('Arial', 16, 'bold'))
    place_leaf()
    t.update()

def display_score(current_score):
    score_turtle.clear()
    score_turtle.penup()
    x = (t.window_width() / 2) - 50
    y = (t.window_height() / 2) - 50
    score_turtle.setpos(x, y)
    score_turtle.write(str(current_score), align='right', font=('Arial', 40, 'bold'))

def place_leaf():
    leaf.color('green')
    leaf.ht()
    max_x = (t.window_width() // 2) - 40
    max_y = (t.window_height() // 2) - 40
    leaf.setx(random.randint(-max_x, max_x))
    leaf.sety(random.randint(-max_y, max_y))
    leaf.st()

def start_game():
    global game_started, caterpillar_length, caterpillar_speed, score
    if game_started:
        return
    game_started = True
    score = 0
    caterpillar_speed = 2
    caterpillar_length = 3
    text_turtle.clear()
    game_over_turtle.clear()
    display_score(score)
    place_leaf()
    for cat in caterpillars:
        cat.showturtle()
        cat.setheading(0)
        cat.shapesize(1, 3, 1)
    move_game()

def move_game():
    global score, caterpillar_length, caterpillar_speed
    if not game_started:
        return
    for i, cat in enumerate(caterpillars):
        cat.setheading(directions[i])
        cat.forward(caterpillar_speed)
    # --- Check for leaf eating with hack distance if hack is on ---
    eaten = False
    for i, cat in enumerate(caterpillars):
        eat_dist = 200 if hack_flags[i] else 70
        if cat.distance(leaf) < eat_dist:
            eaten = True
    if eaten:
        place_leaf()
        caterpillar_length += 1
        caterpillar_speed += 1
        score += 100
        display_score(score)
        for cat in caterpillars:
            cat.shapesize(1, caterpillar_length, 1)
    if any(outside_window(cat) for cat in caterpillars):
        game_over()
        return
    display_hack_status()
    t.update()
    t.ontimer(move_game, 5)  # Lower value = smoother

# --- Movement functions for each player ---
# Player 1: Arrow keys
def move_up1():
    if directions[0] == 0 or directions[0] == 180:
        directions[0] = 90
def move_down1():
    if directions[0] == 0 or directions[0] == 180:
        directions[0] = 270
def move_left1():
    if directions[0] == 90 or directions[0] == 270:
        directions[0] = 180
def move_right1():
    if directions[0] == 90 or directions[0] == 270:
        directions[0] = 0

# Player 2: WASD
def move_up2():
    if directions[1] == 0 or directions[1] == 180:
        directions[1] = 90
def move_down2():
    if directions[1] == 0 or directions[1] == 180:
        directions[1] = 270
def move_left2():
    if directions[1] == 90 or directions[1] == 270:
        directions[1] = 180
def move_right2():
    if directions[1] == 90 or directions[1] == 270:
        directions[1] = 0

# Player 3: IJKL
def move_up3():
    if directions[2] == 0 or directions[2] == 180:
        directions[2] = 90
def move_down3():
    if directions[2] == 0 or directions[2] == 180:
        directions[2] = 270
def move_left3():
    if directions[2] == 90 or directions[2] == 270:
        directions[2] = 180
def move_right3():
    if directions[2] == 90 or directions[2] == 270:
        directions[2] = 0

# --- Key bindings for all three players ---
t.onkey(start_game, 'space')
# Player 1: Arrow keys
t.onkey(move_up1, 'Up')
t.onkey(move_down1, 'Down')
t.onkey(move_left1, 'Left')
t.onkey(move_right1, 'Right')
# Player 2: WASD
t.onkey(move_up2, 'w')
t.onkey(move_down2, 's')
t.onkey(move_left2, 'a')
t.onkey(move_right2, 'd')
# Player 3: IJKL
t.onkey(move_up3, 'i')
t.onkey(move_down3, 'k')
t.onkey(move_left3, 'j')
t.onkey(move_right3, 'l')
t.onkey(reset_game, 'r')

# --- Hack keys (right next to normal controls) ---
t.onkeypress(hack_on1, 'slash')   # '/' key for Player 1
t.onkeyrelease(hack_off1, 'slash')
t.onkeypress(hack_on2, 'e')       # 'e' key for Player 2
t.onkeyrelease(hack_off2, 'e')
t.onkeypress(hack_on3, 'u')       # 'u' key for Player 3
t.onkeyrelease(hack_off3, 'u')

t.listen()
t.mainloop()