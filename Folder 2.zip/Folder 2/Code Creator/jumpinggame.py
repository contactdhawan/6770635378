import pygame
import random

# --- Ask user for FPS ---
try:
    user_fps = int(input("Enter desired FPS (frames per second, e.g. 60): "))
    if user_fps < 1:
        print("FPS must be at least 1. Using default 60.")
        user_fps = 60
except Exception:
    print("Invalid input. Using default FPS of 60.")
    user_fps = 60

# --- Ask user for speed multiplier ---
try:
    speed_multiplier = float(input("Enter game speed multiplier (e.g. 1 for normal, 2 for double speed, 0.5 for half speed): "))
    if speed_multiplier <= 0:
        print("Speed must be positive. Using default 1.")
        speed_multiplier = 1
except Exception:
    print("Invalid input. Using default speed of 1.")
    speed_multiplier = 1

pygame.init()

# --- Window Setup ---
WIDTH, HEIGHT = 800, 400
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("🎉 Blob Runner!")

# --- Clock ---
clock = pygame.time.Clock()
FPS = user_fps

# --- Colors ---
WHITE = (255, 255, 255)
GROUND = (50, 200, 50)
BLOB_COLOR = (100, 100, 255)
OBSTACLE_COLOR = (255, 100, 100)
SKY = (135, 206, 235)
BUTTON_COLOR = (200, 200, 200)
BUTTON_HOVER = (170, 170, 170)
BUTTON_TEXT = (0, 0, 0)

# --- Fonts ---
font = pygame.font.SysFont("Comic Sans MS", 28)
button_font = pygame.font.SysFont("Comic Sans MS", 36)

def draw_button(rect, text, mouse_pos):
    color = BUTTON_HOVER if rect.collidepoint(mouse_pos) else BUTTON_COLOR
    pygame.draw.rect(win, color, rect)
    pygame.draw.rect(win, (100, 100, 100), rect, 2)
    text_surf = button_font.render(text, True, BUTTON_TEXT)
    text_rect = text_surf.get_rect(center=rect.center)
    win.blit(text_surf, text_rect)

def draw_blob(blob, is_jumping):
    squish = 5 if is_jumping else 0
    pygame.draw.ellipse(win, BLOB_COLOR, (blob.x, blob.y + squish, blob.width, blob.height - squish))

def draw_obstacles(obstacles):
    for obs in obstacles:
        pygame.draw.rect(win, OBSTACLE_COLOR, obs)

def draw_ground():
    pygame.draw.rect(win, GROUND, (0, 350, WIDTH, 50))

def draw_sky():
    win.fill(SKY)

def draw_score(score):
    text = font.render(f"Score: {score}", True, (0, 0, 0))
    win.blit(text, (10, 10))

def game_over_screen(score):
    text = font.render("💥 GAME OVER 💥", True, (255, 0, 0))
    win.blit(text, (WIDTH // 2 - 140, HEIGHT // 2 - 60))
    draw_score(score)

def reset_game_state():
    blob = pygame.Rect(100, 300, 50, 50)
    y_velocity = 0
    is_jumping = False
    obstacles = []
    obstacle_interval = 1400
    last_obstacle_time = pygame.time.get_ticks()
    score = 0
    return blob, y_velocity, is_jumping, obstacles, obstacle_interval, last_obstacle_time, score

def main():
    # --- Game State ---
    blob, y_velocity, is_jumping, obstacles, obstacle_interval, last_obstacle_time, score = reset_game_state()
    running = True
    started = False
    game_over_flag = False

    # --- Button Rects ---
    start_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 - 40, 200, 60)
    reset_button = pygame.Rect(WIDTH // 2 - 100, HEIGHT // 2 + 20, 200, 60)

    while running:
        dt = clock.tick(FPS) / 1000  # Delta time in seconds
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if not started:
                if event.type == pygame.MOUSEBUTTONDOWN and start_button.collidepoint(event.pos):
                    started = True
                    # Reset game state in case of restart
                    blob, y_velocity, is_jumping, obstacles, obstacle_interval, last_obstacle_time, score = reset_game_state()
            elif game_over_flag:
                if event.type == pygame.MOUSEBUTTONDOWN and reset_button.collidepoint(event.pos):
                    started = False
                    game_over_flag = False
                    # Reset game state
                    blob, y_velocity, is_jumping, obstacles, obstacle_interval, last_obstacle_time, score = reset_game_state()

        # --- Drawing ---
        draw_sky()
        draw_ground()

        if not started:
            # Draw Start Button
            draw_button(start_button, "Start", mouse_pos)
            pygame.display.update()
            continue

        if game_over_flag:
            game_over_screen(score)
            draw_button(reset_button, "Reset", mouse_pos)
            pygame.display.update()
            continue

        # --- Handle Jump ---
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and not is_jumping:
            y_velocity = -15
            is_jumping = True

        # --- Gravity ---
        y_velocity += 1 * dt * 60 * speed_multiplier
        blob.y += y_velocity * dt * 60 * speed_multiplier
        if blob.y >= 300:
            blob.y = 300
            y_velocity = 0
            is_jumping = False

        # --- Obstacle Generation ---
        current_time = pygame.time.get_ticks()
        if current_time - last_obstacle_time > obstacle_interval:
            height = random.randint(30, 50)
            obs = pygame.Rect(WIDTH, 350 - height, 20, height)
            obstacles.append(obs)
            last_obstacle_time = current_time
            obstacle_interval = random.randint(1000, 1800)

        # --- Move Obstacles ---
        for obs in obstacles[:]:
            obs.x -= 7 * dt * 60 * speed_multiplier
            if obs.right < 0:
                obstacles.remove(obs)
                score += 1

        # --- Collision Detection ---
        for obs in obstacles:
            if blob.colliderect(obs):
                game_over_flag = True

        draw_blob(blob, is_jumping)
        draw_obstacles(obstacles)
        draw_score(score)
        pygame.display.update()

    pygame.quit()

if __name__ == "__main__":
    main()