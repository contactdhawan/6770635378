import tkinter as tk
from tkinter import filedialog, messagebox
import os
import subprocess
import threading

class PyToExeBuilder(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🐍 Py to EXE Builder")
        self.geometry("640x480")
        self.configure(bg="#1e1e2f")

        self.py_file = tk.StringVar()
        self.icon_file = tk.StringVar()
        self.output_dir = tk.StringVar()
        self.onefile = tk.BooleanVar(value=True)
        self.windowed = tk.BooleanVar(value=True)

        self.create_widgets()

    def create_widgets(self):
        def section(label_text):
            tk.Label(self, text=label_text, fg="white", bg="#1e1e2f", anchor="w").pack(padx=10, pady=(10, 0), anchor="w")

        section("Python Script:")
        tk.Entry(self, textvariable=self.py_file, width=60).pack(padx=10)
        tk.Button(self, text="Browse .py", command=self.browse_py).pack(pady=2)

        section("Optional Icon (.ico):")
        tk.Entry(self, textvariable=self.icon_file, width=60).pack(padx=10)
        tk.Button(self, text="Browse .ico", command=self.browse_icon).pack(pady=2)

        section("Output Folder:")
        tk.Entry(self, textvariable=self.output_dir, width=60).pack(padx=10)
        tk.Button(self, text="Choose Output Folder", command=self.browse_output_folder).pack(pady=2)

        tk.Checkbutton(self, text="Bundle into one .exe (--onefile)", variable=self.onefile,
                       bg="#1e1e2f", fg="white").pack(anchor="w", padx=20, pady=(10, 0))
        tk.Checkbutton(self, text="Hide console (GUI app) (--windowed)", variable=self.windowed,
                       bg="#1e1e2f", fg="white").pack(anchor="w", padx=20)

        tk.Button(self, text="🔨 Build EXE", font=("Segoe UI", 12, "bold"),
                  command=self.build_exe).pack(pady=20)

        section("Build Output:")
        self.output_text = tk.Text(self, height=10, bg="#111", fg="#99ffcc", font=("Consolas", 10))
        self.output_text.pack(padx=10, pady=5, fill="both", expand=True)

    def browse_py(self):
        path = filedialog.askopenfilename(filetypes=[("Python files", "*.py")])
        if path:
            self.py_file.set(path)

    def browse_icon(self):
        path = filedialog.askopenfilename(filetypes=[("ICO files", "*.ico")])
        if path:
            self.icon_file.set(path)

    def browse_output_folder(self):
        path = filedialog.askdirectory()
        if path:
            self.output_dir.set(path)

    def build_exe(self):
        py_path = self.py_file.get()
        icon_path = self.icon_file.get()
        out_dir = self.output_dir.get()

        if not py_path.endswith(".py"):
            messagebox.showerror("Missing .py", "Please select a Python file.")
            return

        args = ["-m", "PyInstaller"]
        if self.onefile.get():
            args.append("--onefile")
        if self.windowed.get():
            args.append("--windowed")
        if icon_path:
            args.append(f"--icon={icon_path}")
        if out_dir:
            args += [
                f"--distpath={out_dir}",
                f"--workpath={os.path.join(out_dir, 'build')}",
                f"--specpath={os.path.join(out_dir, 'spec')}"
            ]
        args.append(py_path)

        self.output_text.delete("1.0", tk.END)
        self.output_text.insert(tk.END, f"🛠️ Building {os.path.basename(py_path)}...\n\n")

        def run():
            try:
                process = subprocess.Popen(["python"] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in process.stdout:
                    self.output_text.insert(tk.END, line)
                    self.output_text.see(tk.END)
                process.wait()
                self.output_text.insert(tk.END, "\n✅ Build complete!\n")
            except Exception as e:
                self.output_text.insert(tk.END, f"\n❌ Error: {e}\n")

        threading.Thread(target=run, daemon=True).start()

if __name__ == "__main__":
    app = PyToExeBuilder()
    app.mainloop()