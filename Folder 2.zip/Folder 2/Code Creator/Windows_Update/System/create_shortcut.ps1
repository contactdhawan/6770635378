$target = "$PSScriptRoot\prank.py"  # Use .pyw to hide console
$shortcut = "$env:USERPROFILE\Desktop\System Update.lnk"

$WScriptShell = New-Object -ComObject WScript.Shell
$sc = $WScriptShell.CreateShortcut($shortcut)
$sc.TargetPath = "pythonw.exe"  # No terminal window
$sc.Arguments = "`"$target`""
$sc.WorkingDirectory = "$PSScriptRoot"

# Optional: Set icon (like Windows Update icon)
# $sc.IconLocation = "$env:SystemRoot\System32\shell32.dll,24"

$sc.Save()
