import tkinter as tk
from tkinter import simpledialog
import keyboard
import random, sys, threading, time, winsound, pygame, os

# === CONFIG ===
PASSWORD = 'unfreeze'
SECRET_COMBO = 'ctrl+alt+u'
BACKUP_COMBO = 'ctrl+shift+l'
EMERGENCY_COMBO = 'ctrl+alt+shift+q+w+e+r'
MAX_ATTEMPTS = 3
GLITCH_SOUND = 'glitch.wav'
attempts = 0
countdown_active = False
progress = 0
stuck_point = random.randint(88, 94)

# === SOUND ===
pygame.mixer.init()
def play_loop():
    if os.path.exists(GLITCH_SOUND):
        pygame.mixer.music.load(GLITCH_SOUND)
        pygame.mixer.music.play(-1)
threading.Thread(target=play_loop, daemon=True).start()

# === WINDOW ===
root = tk.Tk()
root.overrideredirect(True)
root.attributes('-topmost', True)
root.geometry(f"{root.winfo_screenwidth()}x{root.winfo_screenheight()}+0+0")
root.configure(bg='black')
canvas = tk.Canvas(root, bg='black', highlightthickness=0)
canvas.pack(fill=tk.BOTH, expand=True)
label = tk.Label(root, text="", font=('Consolas', 22), fg='#ff2222', bg='black', justify='center')
label.place(relx=0.5, rely=0.5, anchor='center')

# === GLITCH EFFECTS ===
def glitch_text(text, amount=0.15):
    chars = list(text)
    gchars = "@#$%^&*!~|[]{}▒▓█"
    return ''.join(random.choice(gchars) if random.random() < amount else c for c in chars)

def draw_glitches():
    canvas.delete("glitch")
    for _ in range(30):
        x1, y1 = random.randint(0, root.winfo_screenwidth()), random.randint(0, root.winfo_screenheight())
        x2, y2 = x1 + random.randint(10, 300), y1 + random.randint(5, 150)
        color = random.choice(['#111111', '#4400ff', '#ffffff', '#222222', '#000000'])
        canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline=color, tags="glitch")
    root.after(100, draw_glitches)

# === BIOS GLITCH SEQUENCE ===
messages = [
    "[ BIOS ERROR 0x0003C0 ] SYSTEM BOOT FAILURE",
    "Initializing automatic repair...",
    "Analyzing boot sectors...",
    "ERROR: Unable to locate EFI partition.",
    "SECURITY BLOCK TRIGGERED - BIOS LOCK ACTIVE",
    "Attempting forced recovery...",
    "Recovery failed. System integrity compromised.",
    "CRITICAL: HDD_BOOT_ACCESS_DENIED",
    "FILE SYSTEM TABLE CORRUPTED",
    "SYSTEM LOCKED - CODE 39X-B",
    "Contact your hardware administrator."
]

def glitch_loop(index=0):
    if index < len(messages):
        label.config(text=glitch_text(messages[index], 0.2))
        root.after(random.randint(500, 900), glitch_loop, index + 1)
    else:
        glitch_progress()

def glitch_progress():
    global progress
    if progress < stuck_point:
        bar = f"[{'█'*progress}{'▒'*(100 - progress)}] {progress}%"
        label.config(text=f"⚙️ Attempting repair...\n\n{glitch_text(bar, 0.05)}")
        progress += random.choice([1, 2, 0])
        root.after(random.randint(70, 130), glitch_progress)
    else:
        label.config(text="🔒 SYSTEM LOCKED\n\nUNAUTHORIZED CHANGE DETECTED")

# === COUNTDOWN ===
def start_countdown():
    global countdown_active
    countdown_active = True
    for i in range(10, 0, -1):
        label.config(text=f"🔨 SYSTEM FORMAT INITIATED...\n\nFormatting C:\\ in {i} seconds...")
        winsound.Beep(500 + i*30, 200)
        time.sleep(1)
    label.config(text="💥 FORMAT COMPLETE\nYour data is gone.\n\nRebooting...")
    winsound.Beep(200, 1000)
    time.sleep(2)
    fake_reboot()

# === BSOD ===
def fake_reboot():
    label.place_forget()
    canvas.delete("all")
    canvas.configure(bg='#0000aa')
    canvas.create_text(
        root.winfo_screenwidth()//2, root.winfo_screenheight()//2,
        text=("A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
              "The problem seems to be caused by the following file: BIOS_LOCK.sys\n\n"
              "PAGE_FAULT_IN_NONPAGED_AREA\n\n"
              "*** STOP: 0x00000050 (0xFFFFF880009AA000, 0x0000000000000000, 0xFFFFF80002ACD8F0, 0x0000000000000002)"),
        font=("Consolas", 16), fill="white", width=root.winfo_screenwidth()-100, justify='left')
    winsound.Beep(100, 1200)

# === UNLOCK SYSTEM (safe version, both hotkeys) ===
def unlock():
    global attempts, countdown_active
    if countdown_active:
        return

    try:
        keyboard.remove_hotkey(SECRET_COMBO)
    except: pass
    try:
        keyboard.remove_hotkey(BACKUP_COMBO)
    except: pass

    try:
        root.withdraw()
        pw = simpledialog.askstring("BIOS UNLOCK", "Enter admin password:", show='*')
        root.deiconify()

        if pw is None:
            label.config(text="⛔ Unlock cancelled.")
        elif pw.strip().lower() == PASSWORD.lower():
            label.config(text="✔️ ACCESS GRANTED\nShutting down lock...")
            root.update()
            time.sleep(1)
            root.destroy()
            sys.exit()
        else:
            attempts += 1
            label.config(text="❌ ACCESS DENIED")
            winsound.Beep(300, 300)
            if attempts >= MAX_ATTEMPTS:
                threading.Thread(target=start_countdown).start()
    except Exception as e:
        label.config(text=f"Error: {e}")
        winsound.Beep(400, 200)

    if not countdown_active:
        keyboard.add_hotkey(SECRET_COMBO, unlock)
        keyboard.add_hotkey(BACKUP_COMBO, unlock)

# === EMERGENCY EXIT ===
def emergency_kill():
    print("💀 EMERGENCY KILL COMBO PRESSED")
    try:
        root.destroy()
    except:
        pass
    try:
        sys.exit()
    except:
        pass
    os._exit(0)

# === PREVENT EXIT ===
def disable_event(*args): return "break"
root.bind("<Alt-F4>", disable_event)
root.protocol("WM_DELETE_WINDOW", disable_event)

# === HOTKEYS ===
keyboard.add_hotkey(SECRET_COMBO, unlock)
keyboard.add_hotkey(BACKUP_COMBO, unlock)
keyboard.add_hotkey(EMERGENCY_COMBO, emergency_kill)

# === START ===
draw_glitches()
glitch_loop()
root.mainloop()
